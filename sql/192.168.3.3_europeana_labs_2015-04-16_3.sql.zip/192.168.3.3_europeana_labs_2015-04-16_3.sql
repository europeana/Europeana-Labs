# ************************************************************
# Sequel Pro SQL dump
# Version 4135
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 192.168.3.3 (MySQL 5.5.41-0ubuntu0.12.04.1)
# Database: europeana_labs
# Generation Time: 2015-04-16 14:03:40 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table bolt_authtoken
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_authtoken`;

CREATE TABLE `bolt_authtoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `token` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `lastseen` datetime DEFAULT NULL,
  `ip` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `useragent` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `validity` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_740AC52FF85E0677` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_authtoken` WRITE;
/*!40000 ALTER TABLE `bolt_authtoken` DISABLE KEYS */;

INSERT INTO `bolt_authtoken` (`id`, `username`, `token`, `salt`, `lastseen`, `ip`, `useragent`, `validity`)
VALUES
	(2,'bob','bdd16daf9181afe6530e8ebe0cb314b5','z0PJbQhiToGX','2015-03-04 14:11:07','192.168.3.3','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36','2015-03-18 14:11:07'),
	(3,'bob','67467605130204199821d16948bb2fc1','eu7LNq4rL5tB','2015-03-04 12:57:40','192.168.3.3','Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36','2015-03-18 12:57:40'),
	(12,'bob','d1e1bebcbd18dd818ec3c3c60c861b25','UL4k0a00rfWx','2015-03-09 13:01:14','192.168.3.3','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.76 Safari/537.36','2015-03-23 13:01:14'),
	(18,'bob','bc50e8f140b541bfa911ce9e02e32128','gTKjYwthe1Hj','2015-03-26 10:04:38','62.41.227.121','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36','2015-04-09 10:04:38'),
	(51,'bob','43abf78975802bc55c854bffed9f01e6','SScy4auvXgrA','2015-04-09 15:45:57','62.41.227.121','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36','2015-04-23 15:45:57');

/*!40000 ALTER TABLE `bolt_authtoken` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_blogposts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_blogposts`;

CREATE TABLE `bolt_blogposts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `datecreated` datetime NOT NULL,
  `datechanged` datetime NOT NULL,
  `datepublish` datetime DEFAULT NULL,
  `datedepublish` datetime DEFAULT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `ownerid` int(11) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `body` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` longtext COLLATE utf8_unicode_ci NOT NULL,
  `attachments` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6D96B2CA989D9B62` (`slug`),
  KEY `IDX_6D96B2CAAFBA6FD8` (`datecreated`),
  KEY `IDX_6D96B2CABE74E59A` (`datechanged`),
  KEY `IDX_6D96B2CAA5131421` (`datepublish`),
  KEY `IDX_6D96B2CAB7805520` (`datedepublish`),
  KEY `IDX_6D96B2CA7B00651C` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_blogposts` WRITE;
/*!40000 ALTER TABLE `bolt_blogposts` DISABLE KEYS */;

INSERT INTO `bolt_blogposts` (`id`, `slug`, `datecreated`, `datechanged`, `datepublish`, `datedepublish`, `username`, `ownerid`, `status`, `title`, `body`, `image`, `attachments`)
VALUES
	(1,'research-the-local-history-of-girona','2015-03-04 12:08:13','2015-04-09 09:20:14','2015-03-04 12:08:13',NULL,'',2,'draft','Research the Local History of Girona','<p><em>Europeana has a wealth of content available to researchers, both through its portal and its <a href=\"http://labs.europeana.eu/api\">APIs</a>. Europeana Research highlights this content and its research potential. This article by Eliza Papaki, Research Assistant at the <a href=\"http://www.dcu.gr\"> Digital Curation Unit </a>, along with others in the series, focuses on collections of interest to the academic community.</em></p>\r\n\r\n<p>One of the many collections available to researchers via the Europeana portal and an API is a rich collection of over 2,000 photographs and postcards presenting the <a href=\"http://labs.europeana.eu/data/art-and-life-on-postcards-and-photographs-from-girona/\">art and life of the Spanish city Girona </a>. It covers nearly a century of history (from 1839 to 1930) and a range of topics, from cork stopper factories to tombs of the clergy and city monuments.</p>\r\n\r\n<p><img alt=\"N.o 5.-Gerona.-Nuevas Ramblas., Rights:Unknown\" src=\"/files/Images/Europeana_Research/065397.jpg\" style=\"width: 450px; height: 294px;\" title=\"N.o 5.-Gerona.-Nuevas Ramblas., Rights:Unknown\" /></p>\r\n\r\n<p><em><a href=\"http://www.europeana.eu/portal/record/2024914/photography_ProvidedCHO_Ajuntament_de_Girona_065397.html?start=40&amp;query=europeana_collectionName%3A2024914*&amp;startPage=25&amp;qf=RIGHTS%3Ahttp%3A%2F%2Fcreativecommons.org%2Fpublicdomain%2Fmark%2F1.0%2F*&amp;qt=false&amp;rows=24\">N.o 5.-Gerona.-Nuevas Ramblas.</a>, Rights:Unknown.</em></p>\r\n\r\n<p>How could this interesting and rich collection be useful to researchers? Simply browsing this content can lead to observations on handwriting, clothing, financial occupation of the population or even urban architecture. It could thus be said that it is a collection with multiple interpretations which serves the research interests of a variety of disciplines. Researchers wandering through the large number of postcards can simply be inspired to set innovative research topics and questions for their essays or dissertations.</p>\r\n\r\n<p>Reconstructing the history of a city, its development through time and its traditions, can be an amazing adventure for local historians who wish to interpret the history of a local community. Dated in the 19th and 20th centuries, this collection serves as a ‘living testimony’ of the city of Girona which could not be approached through oral testimonies for example. On the other hand, since many of the postcards have written messages on them preserved during the digitization process, local historians may be lucky enough to reveal the microhistory of a citizen or family of Girona by transcribing these messages!</p>\r\n\r\n<p></p>\r\n\r\n<p>There are a few considerations to be aware of when accessing this collection.</p>\r\n\r\n<p>First, despite the name ‘Girona’ in the title, not all results relate to the city of Girona. This is because the term ‘Girona’ relates to the fact that the images have been provided by the Spanish organisation <a href=\"http://www2.girona.cat/ca\" style=\"text-decoration:none;\"> Ajuntament de Girona</a>. Researchers will therefore find images of other destinations, including the French capital Paris, alongside the predominantly Spanish content.</p>\r\n\r\n<p>It is also important to note that the Ajuntament de Girona has provided all item descriptions in Spanish. Researchers who do not speak Spanish can overcome this barrier by using the translations available via the Europeana portal. Translations are also available when searching the collection, which means that English-speakers can refine their search by terms such as ‘bridge’ or ‘palace’, rather than ‘puente’ or ‘palacio’.</p>\r\n\r\n<p></p>','{\"file\":\"Images\\/Europeana_Research\\/065397.jpg\",\"title\":\"Caption: N.o 5.-Gerona.-Nuevas Ramblas.,  Collecio Josep Bronsoms, Ajuntament de Girona.  Rights: Public Domain\"}','[]'),
	(181,'six-centuries-of-maps-for-cartographic-and-geographic-researchers','2015-03-09 13:22:55','2015-04-09 09:14:11','2015-03-09 13:01:11',NULL,'',4,'draft','Six Centuries of Maps For Cartographic and Geographic Researchers','<p><em>Europeana has a wealth of content available to researchers, both through its portal and its <a href=\"http://labs.europeana.eu/api\">APIs</a>. Europeana Research highlights this content and its research potential. This article by Stefan Ekman, Research Coordinator at the <a href=\"http://snd.gu.se/en/start\">Swedish National Data Service</a>, along with others in the series, focuses on collections of interest to the academic community.</em></p>\r\n\r\n<p><strong>First Collection Title</strong>: Maps and Drawings from the Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales<br />\r\n<strong>Source</strong>: Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales <strong>Licence for Metadata</strong>: CC0<br />\r\n<strong>Licence for Content</strong>: Public domain<br />\r\n<strong>Data Formats</strong>: Image, Text<br />\r\n<strong>Metadata Format</strong>: EDM (Europeana Data Model)<br />\r\n<strong>How Accessed</strong>: <a href=\"http://www.europeana.eu/portal/search.html?query=DATA_PROVIDER:%22Cat%C3%A1logo%20Colectivo%20de%20la%20Red%20de%20Bibliotecas%20de%20los%20Archivos%20Estatales%22&amp;qf=TYPE:IMAGE\">Europeana Portal</a>, <a href=\"http://labs.europeana.eu/api/console/?function=search&amp;query=DATA_PROVIDER:%22Cat%C3%A1logo%20Colectivo%20de%20la%20Red%20de%20Bibliotecas%20de%20los%20Archivos%20Estatales%22&amp;qf=TYPE:IMAGE\">API console</a></p>\r\n\r\n<p><strong>Second Collection Title</strong>: Maps and Drawings from the Biblioteca Virtual del Patrimonio Bibliográfico<br />\r\n<strong>Source</strong>: Biblioteca Virtual del Patrimonio Bibliográfico<br />\r\n<strong>Licence for Metadata</strong>: CC0<br />\r\n<strong>Licence for Content</strong>: Public domain<br />\r\n<strong>Data Format</strong>: Image, Text<br />\r\n<strong>Metadata Format</strong>: EDM (Europeana Data Model)<br />\r\n<strong>How Accessed</strong>: <a href=\"http://www.europeana.eu/portal/search.html?query=DATA_PROVIDER:%22Biblioteca%20Virtual%20del%20Patrimonio%20Bibliogr%C3%A1fico%22&amp;qf=TYPE:IMAGE\">Europeana Portal</a>, <a href=\"http://labs.europeana.eu/api/console/?function=search&amp;query=DATA_PROVIDER:%22Biblioteca%20Virtual%20del%20Patrimonio%20Bibliogr%C3%A1fico%22&amp;qf=TYPE:IMAGE\">API console</a></p>\r\n\r\n<p>Two datasets available through Europeana Labs stand out for researchers interested in cartography, historical geography and the history of map-making, as well as those working with cultural geography, urban studies and issues related to to the growing interest in spatial and geographic perspectives in the social sciences (“the spatial turn”).</p>\r\n\r\n<p><a href=\"http://labs.europeana.eu/data/Maps-and-Drawings-from-the-Cat%C3%A1logo-Colectivo-De-La-Red-De-Bibliotecas-De-Los-Archivos-Estatales/\">Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales</a> and <a href=\"http://labs.europeana.eu/data/Maps-and-Drawings-from-the-Biblioteca-Virtual-Del-Patrimonio-Bibliografico/\">Biblioteca Virtual del Patrimonio Bibliográfico</a> together total some 9,000 objects, including portolan charts, city plans, and drawings of buildings and fortifications. These maps span the period from the 16th to the 20th century, and they are all in the public domain.</p>\r\n\r\n<p><br />\r\n<img alt=\"Edinburgh from Civitates Orbis Terrarum, vol. III, p. 39; Universitäts- und Landesbibliothek Düsseldorf. Rights: Rights Reserved - Free Access.\" src=\"https://lh5.googleusercontent.com/2H5BpVjeY4vw1CbmXFtZSa0xETNearby4mQ9GfCe-RMirp-7pl3MP_PXuvbXCUviujVAz_gJJHvBjnEoz7wGd7f657b6ZKNVLlOrFqjTAtPqvXjFdI5_FyXXdtBJg94G2Ry7wTA\" title=\"Edinburgh from Civitates Orbis Terrarum, vol. III, p. 39; Universitäts- und Landesbibliothek Düsseldorf. Rights: Rights Reserved - Free Access.\" /><br />\r\n<em><a href=\"http://www.europeana.eu/portal/record/09428/urn_nbn_de_hbz_061_1_67166.html?query=Civitates+Orbis+Terrarum&amp;qf=edinburgh&amp;qt=false\">Edinburgh from Civitates Orbis Terrarum, vol. III, p. 39</a>; Universitäts- und Landesbibliothek Düsseldorf. Rights: <a href=\"http://www.europeana.eu/portal/rights/rr-f.html\">Rights Reserved - Free Access</a>. This map is found in the third volume of Georg Braun’s major cartographic work from 1588. Worth noting is his attention to detail in the oblique perspective (for instance of Edinburgh Castle) and the typical figures in the foreground. Braun’s Civitates arguably brought in a new era of cartography.</em></p>\r\n\r\n<p>The dataset from Biblioteca Virtual mainly contains maps from the 18th and 19th centuries – just over 1,000 and 2,000 maps, respectively. There are also 16th century maps (mainly portolan charts of Spanish and Dutch origin) and three of the six volumes of the wonderful 16th century Civitates Orbis Terrarum. This work contains more than 500 maps of cities from all around the world, 230 of which can be found in the available volumes.</p>\r\n\r\n<p><br />\r\n<img alt=\"Plano en perspectiva de la Villa de Aranda de Duero, Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales. Rights: Public Domain/No Copyright.\" src=\"https://lh3.googleusercontent.com/82ydVGU6SzeawDSAaHeHgDt3h80VOiGMFcWZ3sSejRsqsQgRIYOM5HAJXqbMc1-u3HMNB5Hzdm0NlDFyaNjvdsl-yruCROTNa7d20mM6NHDK51qxTGM-PN4Vez0O5m0h5gl4IXE\" title=\"Plano en perspectiva de la Villa de Aranda de Duero, Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales. Rights: Public Domain/No Copyright.\" /><br />\r\n<em><a href=\"http://www.europeana.eu/portal/record/2022701/oai_rebae_mcu_es_179381.html?start=1&amp;query=Plano+en+perspectiva+de+la+Villa+de+Aranda+de+Duero&amp;startPage=1&amp;qt=false&amp;rows=24\">Plano en perspectiva de la Villa de Aranda de Duero</a>, Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales. Rights: Public Domain/No Copyright. An interesting example of Renaissance mapmaking, of the town Aranda de Duero in present-day Castile and León. Created in 1503, it was submitted to the Royal Council of Castile together with information in connection with the opening of the Barrionuevo street.</em></p>\r\n\r\n<p>The maps in Braun’s Civitates are colourful, detailed bird’s-eye view pictures, offering a street plan and locations of important buildings like castles and cathedrals. They are what Ptolemy would have called chorographica, more artistic representations of a small region, rather than geographica, maps of countries or the world. The three volumes are scanned at high resolution (allowing for detailed analysis) and each page can be downloaded separately from the data provider.</p>\r\n\r\n<p>In addition to their cartographic appeal, these are works of great beauty, adorned with a variety of surround elements and illustrations that themselves offer analytical routes into the maps. They offer value to urban studies researchers, who may be following the development of the urban settlements, and to researchers who are negotiating the role of space and place in, for instance, the organisation and regulation of society.</p>\r\n\r\n<p>The other collection, the Catálogo Colectivo, contains over 5,000 maps and is dominated by 18th century content. Profile drawings of buildings, nautical charts, and road maps are some of the more special kinds of maps available. There is also sufficient 16th and 17th century material to study how maps have developed over time. The earliest object in the dataset, the 1503 Plano en perspectiva de la Villa de Aranda de Duero, uses an early approach to perspectival mapping and marks the starting point for a cavalcade of methods of mapping three-dimensional space onto a two-dimensional surface. Through the various maps, it is for instance possible to see how hachures develop from their early Renaissance form to the shading of the 19th century, and how land forms change from stylised representations to attempts at faithful renderings of the mapped landscape.</p>\r\n\r\n<p>These datasets, provided by state archives and libraries in Spain, offer possibilities to explore how space and place have been codified over the centuries, and how societies have been spatially organised. They allow us to examine the ways in which our three-dimensional surroundings have been reduced to two dimensions for various purposes – utilitarian as well as artistic. Finally, they provide a way to look at the past through the minds and pens of those who lived there.</p>\r\n\r\n<div></div>','{\"file\":\"Images\\/Europeana_Research\\/ryh-1402-15.jpg\",\"title\":\"\"}','[]'),
	(182,'introducing-europeana-research','2015-04-14 11:27:35','2015-04-14 14:33:34','2015-04-14 11:24:27',NULL,'',4,'published','Introducing Europeana Research','<p>The digitisation of Europe\'s cultural heritage has provided ample opportunity for researchers to accelerate or make substantial changes to their working processes.</p>\r\n\r\n<p>The explosion of the digital approaches to this data means that researchers are increasingly asking for more than traditional interfaces to search and browse. Access to entire datasets for download for text and data mining, or access to APIs to build specific tools.</p>\r\n\r\n<p>With this in mind, we are building Europeana Research as a means of better connecting with the research community, with a particular focus on digital humanities and social sciences</p>\r\n\r\n<p>Over the next few months, we will be working with some of the existing metadata and content we have aggregated to make that open for re-use. We also will be addressing some more strategic issues, such as how to leverage big data sets for research re-use and how Europeana\'s content strategy should evolve to support research.</p>\r\n\r\n<p>Europeana will not be able to do this alone - there are plenty of challenges in terms of technology, rights and sustainability. So we will work with infrastructures such as DARIAH, CLARIN and projects such as <a href=\"http://dm2e.eu/\">DM2E</a> (Digitised Manuscripts to Europeana) to see how joined-up solutions can be created.</p>\r\n\r\n<p>Find out more <a href=\"http://research.europeana.eu/about-us/roadmap\">about our plans</a> and <a href=\"https://twitter.com/eurresearch\">follow us on Twitter</a></p>\r\n\r\n<p></p>','{\"file\":\"2015-04\\/regiacharlesv-bnf-fr.2810.jpg\",\"title\":\"Pages from \'Marco Polo, Le Livre des merveilles\', http:\\/\\/gallica.bnf.fr\\/ark:\\/12148\\/btv1b52000858n\\/f9.image.r=Fran%C3%A7ais%202810.langEN\"}','[]'),
	(183,'why-are-projects-like-dm2e-important-for-europeana-s-future','2015-04-15 07:24:36','2015-04-16 13:45:04','2015-04-15 07:19:11',NULL,'',4,'published','Why are projects like Digital Manuscripts to Europeana important for Europeana’s future?','<p>Moving from a portal to a platform: this is one of Europeana’ s<a href=\"http://strategy2020.europeana.eu/\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> major objectives for 2015-2020</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(26, 26, 26); vertical-align: baseline; white-space: pre-wrap;\"> in order to allow “people to re-use and play with the material, to interact with others and participate in creating something new”. </span><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Europeana can’t achieve this vision on its own and it needs the support of its Network and other valuable related projects. The Digital Manuscripts to Europeana project (DM2E) is one of these projects. </span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Launched in February 2012 and ending last January, the DM2E project focused on the development of Linked Data based solutions and tools that enable libraries and archives to provide digital manuscripts to Europeana. Along the way, the project developed a new data model for manuscripts, and technical solutions to allow the description, the manipulation and enrichment of the data. The results were promoted within and validated by the Digital Humanities community. </span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">So what makes the results of the DM2E project beneficial to Europeana?</span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Europeana’s broad vision is supported by activities running on three different levels: </span><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> </span></span></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"></p>\r\n\r\n<ul style=\"margin-top:0pt;margin-bottom:0pt;\">\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">A </span><span style=\"font-weight: bold; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Core</span><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> where we collect the data, content and technology.</span></span></p>\r\n    </li>\r\n</ul>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"></p>\r\n\r\n<ul style=\"margin-top:0pt;margin-bottom:0pt;\">\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">An </span><span style=\"font-weight: bold; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Access</span><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> level where we standardise and enrich the core, define the rules of engagement and provide the interfaces for access.</span></span></p>\r\n    </li>\r\n</ul>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"></p>\r\n\r\n<ul style=\"margin-top:0pt;margin-bottom:0pt;\">\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">And a </span><span style=\"font-weight: bold; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Service</span><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> level, where we develop tailored experiences for our three user groups: Professionals, End-Users and Creatives. </span></span></p>\r\n    </li>\r\n</ul>\r\n\r\n<p></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">DM2E makes a positive contribution to all three of these levels.</span></span></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"><img height=\"410px;\" src=\"https://lh3.googleusercontent.com/guF36sII8yXdrvsArWs_brkzoXp6nJQTmfANLK6O4G0kZ6H2gdhv8nLOfd_iAlJ7AfqUMT-16PCYXzANZouE503fnKeTCSsz-5tK_-jrFPMqFTrT692u1bgn8WxBdtIBkfklUvQ\" style=\"border: none; transform: rotate(0.00rad); -webkit-transform: rotate(0.00rad);\" width=\"545px;\" /></span></span></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">From the </span><a href=\"http://pro.europeana.eu/files/Europeana_Professional/Publications/Europeana%20Strategy%202020.pdf\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Europeana Strategy 2015-2020</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">.Visuals by Elco van Staveneren, www.denkschets.nl (CC-BY-SA) </span></span></p>\r\n\r\n<p></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); font-weight: bold; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Improving Europeana’s core</span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">DM2E brings additional 20.08 million manuscripts pages from national libraries, archives and research institutions across Europe. These manuscripts come from important corpora for Digital Humanities researchers. Until this project, modern manuscripts were underrepresented in Europeana. Furthermore, this content enriches Europeana in multilingual data. Content and data cover a variety of languages: German, Latin, French, Italian, English, Czech but also Arabic and Turkish, less represented in Europeana.</span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The metadata couldn’t be integrated into Europeana without defining a proper interoperability framework. The </span><a href=\"http://dm2e.eu/files/DM2E_Model_V1.2.pdf\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">DM2E model </span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">is developed using the </span><a href=\"http://pro.europeana.eu/edm-documentation\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Europeana Data Model </span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">(EDM) and specialises it to support the requirements of the project. The DM2E model allows the description of rich metadata for manuscripts, answering the needs of scholars without hindering the interoperability with Europeana as the DM2E model is built on top of the Europeana one. </span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Discussions during the project enabled the creation of mapping recommendations that have been useful to Europeana for improving its model. The model also demonstrates how EDM can be extended so as to support different grains of data. The discussions around the development of the DM2E model and EDM application profiles in general were also opened out to the wider community in a </span><a href=\"http://wiki.dublincore.org/index.php/RDF_Application_Profiles\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">task group</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> at the Dublin Core Metadata Initiative. The issues are currently being discussed with Europeana as well as other partners such as the </span><a href=\"https://www.deutsche-digitale-bibliothek.de/\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">German Digital Library</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> or </span><a href=\"http://dp.la/\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">DPLA</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">. </span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The DM2E model is only one building block within a larger </span><a href=\"http://dm2e.eu/files/D2.3_1.0_WP2_Final_Version_of_the_Interoperability_Infrastructure_140214_final.pdf\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">interoperability infrastructure </span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">allowing:</span></span></p>\r\n\r\n<ul style=\"margin-top:0pt;margin-bottom:0pt;\">\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The description of metadata transformation, provenance, versioning workflows. </span></span></p>\r\n    </li>\r\n</ul>\r\n\r\n<ul style=\"margin-top:0pt;margin-bottom:0pt;\">\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The mapping of the original metadata (in various formats) to the DM2E model and then to the Europeana EDM. </span></span></p>\r\n    </li>\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The contextualisation of resources by the generation of links to external sources (performed with </span><a href=\"http://wifo5-03.informatik.uni-mannheim.de/bizer/silk/\" style=\"text-decoration:none;\"><span style=\"color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Silk</span></a><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">)</span></span></p>\r\n    </li>\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The dissemination of RDF data via a Linked Data API</span></span></p>\r\n    </li>\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The access of the transformed EDM data via an OAI-PMH service</span></span></p>\r\n    </li>\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The </span><a href=\"http://dm2e.eu/files/D2.3_1.0_WP2_Final_Version_of_the_Interoperability_Infrastructure_140214_final.pdf\" style=\"text-decoration:none;\"><span style=\"color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">OmNom</span></a><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> engine independently integrates and orchestrates the tools supporting these different workflows. </span></span></p>\r\n    </li>\r\n</ul>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">All the DM2E tools are the outcome of a great deal of innovation work.</span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">This flexibility of the aggregation services built by DM2E is what Europeana hopes to achieve for its own aggregation services but also for its network of providers and aggregators. This impressive infrastructure could benefit Europeana own services, but also other organisations within the Network who share the same needs. </span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); font-weight: bold; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Providing access to data, content and technology</span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Bringing new data to the Europeana core and improving the overall data quality is a great achievement, but becomes even more valuable if Europeana can provide access to it. The DM2E project has developed ways to allow the content, the data and technology to be re-used after the project ends. </span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The publication of the data under the Creative Commons CC0 licence enables the data to be openly accessed. The Linked Data API developed by DM2E facilitates the distribution </span></span><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">of the data while the enrichments performed on the data enables a better access to resources by the Digital Humanities community. All these tools have been made available as open source software. </span></span></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); font-weight: bold; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Offering new services</span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">By encouraging humanists to work with Linked Data, the DM2E project has nurtured a thriving relationship with a community that was, until this point, not well-represented in the Europeana Network. </span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The analysis of the research processes in the humanities supported the development of a series of digital tools included in the Scholarly Research Platform. The created </span><a href=\"http://dm2e.eu/files/D3.4_2.0_Research_Report_on_DH_Scholarly_Primitives_150402.pdf\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">model</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> defines new types of scholarly activities involving collaborative commenting, annotating, collecting, and the sharing data. The results of the DM2E project were tested and validated by scholars in experiments. </span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The Scholarly Research Platform is based on the open source tool </span><a href=\"http://thepund.it/\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Pundit </span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">which </span></span></p>\r\n\r\n<ul style=\"margin-top:0pt;margin-bottom:0pt;\">\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">allows users to create structured data while annotating pages and text on the Web.</span></span></p>\r\n    </li>\r\n    <li dir=\"ltr\" style=\"list-style-type: disc; font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; background-color: transparent;\">\r\n    <p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">supports the semantic linking of text and images to the DM2E data but also to controlled vocabularies and taxonomies. </span></span></p>\r\n    </li>\r\n</ul>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">This approach completes Europeana’s recent work around </span><a href=\"http://pro.europeana.eu/europeana-aat/\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">data enrichment</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> and the development of its “semantic layer”. </span></span></p>\r\n\r\n<p></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"><img alt=\"dm2e_eu_files_Public_Final_Report_150331_pdf.jpg\" height=\"344px;\" src=\"https://lh3.googleusercontent.com/1KEr_Gb_crTNOxjhcacufjbLKCRa2CR4K2iM1pU4Q6MiDuvfog2ZEqkdONQUqc0Y001DUZ8O3LMpArpda6rv9xuPthSKmiZiF7yaWzn560EYhQAz8wIFfxsbfavbTdHLzqqRqlk\" style=\"border: none; transform: rotate(0.00rad); -webkit-transform: rotate(0.00rad);\" width=\"624px;\" /></span></span></p>\r\n\r\n<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;\"><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Scholarly Research Platform “Pundit”: The software ecosystem overview</span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Europeana is now in the position to re-use the efforts made by the DM2E project to elaborate the new </span><a href=\"http://research.europeana.eu/\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">Europeana Research</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> and the developments of the services it will offers. Projects such as DM2E indicate areas that Europeana should be exploring to deepen that relationship and provide more meaningful links between the GLAM sector and the digital humanities.</span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">in addition, the DM2E project participated in bringing new communities into the Europeana Network around topics such as open data, and data trust. </span><a href=\"http://openhumanitiesawards.org/\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">The Open Humanities Awards</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">, for instance, demonstrate how the research community can foster innovation around cultural heritage data, while the </span><a href=\"http://openglam.org/\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">OpenGLAM community</span></a><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\"> initiated by Open Knowledge in the DM2E project works on promoting and furthering free and open access to digital cultural heritage. </span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">All these results shows how R&amp;D developments can support the Europeana platform and its future services. The work of the DM2E affects all the levels of the platform: it improves its core, provides new ways to access and re-use materials and brings promise of great services in the future. </span></span></p>\r\n\r\n<p><span id=\"docs-internal-guid-7ec6ab29-bbf4-9ca5-404d-aeb10487be7f\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">All the DM2E outputs, publication and results can be found at </span><a href=\"http://dm2e.eu/outputs/\" style=\"text-decoration:none;\"><span style=\"font-size: 15px; font-family: Calibri; color: rgb(17, 85, 204); text-decoration: underline; vertical-align: baseline; white-space: pre-wrap; background-color: transparent;\">http://dm2e.eu/outputs/</span></a></span></p>\r\n\r\n<p></p>','{\"file\":\"2015-04\\/79ffa223532148abf3bf2f3cbead6795.jpeg\",\"title\":\"\"}','[]');

/*!40000 ALTER TABLE `bolt_blogposts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_collections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_collections`;

CREATE TABLE `bolt_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `datecreated` datetime NOT NULL,
  `datechanged` datetime NOT NULL,
  `datepublish` datetime DEFAULT NULL,
  `datedepublish` datetime DEFAULT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `ownerid` int(11) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `intro` longtext COLLATE utf8_unicode_ci NOT NULL,
  `teaser` longtext COLLATE utf8_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8_unicode_ci NOT NULL,
  `teaser_image` longtext COLLATE utf8_unicode_ci NOT NULL,
  `secondary_mail` tinyint(1) NOT NULL DEFAULT '0',
  `hide_list` tinyint(1) NOT NULL DEFAULT '0',
  `filelist_files` longtext COLLATE utf8_unicode_ci NOT NULL,
  `filelist_downloads` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hide_related` tinyint(1) NOT NULL DEFAULT '0',
  `hide_related_section` tinyint(1) NOT NULL DEFAULT '0',
  `listtitle` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `imagelist` longtext COLLATE utf8_unicode_ci NOT NULL,
  `liststyle` longtext COLLATE utf8_unicode_ci NOT NULL,
  `support_navigation` longtext COLLATE utf8_unicode_ci NOT NULL,
  `source` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `source_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `IDX_6EC4CAA6989D9B62` (`slug`),
  KEY `IDX_6EC4CAA6AFBA6FD8` (`datecreated`),
  KEY `IDX_6EC4CAA6BE74E59A` (`datechanged`),
  KEY `IDX_6EC4CAA6A5131421` (`datepublish`),
  KEY `IDX_6EC4CAA6B7805520` (`datedepublish`),
  KEY `IDX_6EC4CAA67B00651C` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_collections` WRITE;
/*!40000 ALTER TABLE `bolt_collections` DISABLE KEYS */;

INSERT INTO `bolt_collections` (`id`, `slug`, `datecreated`, `datechanged`, `datepublish`, `datedepublish`, `username`, `ownerid`, `status`, `title`, `intro`, `teaser`, `body`, `teaser_image`, `secondary_mail`, `hide_list`, `filelist_files`, `filelist_downloads`, `hide_related`, `hide_related_section`, `listtitle`, `imagelist`, `liststyle`, `support_navigation`, `source`, `source_url`)
VALUES
	(1,'six-centuries-of-maps-for-cartographic-and-geographic-researchers','2015-04-09 09:07:53','2015-04-16 13:43:57','2015-04-09 09:07:36',NULL,'',3,'published','Six Centuries of Maps For Cartographic and Geographic Researchers','Europeana has a wealth of content available to researchers, both through its portal and its APIs. Europeana Research highlights this content and its research potential.','<p>This article by Stefan Ekman, Research Coordinator at the Swedish National Data Service, along with others in the series, focuses on collections of interest to the academic community.</p>','<p dir=\"ltr\" style=\"line-height:1.38;margin-top:0pt;margin-bottom:0pt;text-align: right;\"></p>\r\n\r\n<p><strong>First Collection Title</strong>: Maps and Drawings from the Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales<br />\r\n<strong>Source</strong>: Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales<br />\r\n<strong>Licence for Metadata</strong>: CC0<br />\r\n<strong>Licence for Content</strong>: Public domain<br />\r\n<strong>Data Formats</strong>: Image, Text<br />\r\n<strong>Metadata Format</strong>: EDM (Europeana Data Model)<br />\r\n<strong>How Accessed</strong>: <a href=\"http://www.europeana.eu/portal/search.html?query=DATA_PROVIDER:%22Cat%C3%A1logo%20Colectivo%20de%20la%20Red%20de%20Bibliotecas%20de%20los%20Archivos%20Estatales%22&amp;qf=TYPE:IMAGE\">Europeana Portal</a>, <a href=\"http://labs.europeana.eu/api/console/?function=search&amp;query=DATA_PROVIDER:%22Cat%C3%A1logo%20Colectivo%20de%20la%20Red%20de%20Bibliotecas%20de%20los%20Archivos%20Estatales%22&amp;qf=TYPE:IMAGE\">API console</a></p>\r\n\r\n<p><strong>Second Collection Title</strong>: Maps and Drawings from the Biblioteca Virtual del Patrimonio Bibliográfico<br />\r\n<strong>Source</strong>: Biblioteca Virtual del Patrimonio Bibliográfico<br />\r\n<strong>Licence for Metadata</strong>: CC0<br />\r\n<strong>Licence for Content</strong>: Public domain<br />\r\n<strong>Data Format</strong>: Image, Text<br />\r\n<strong>Metadata Format</strong>: EDM (Europeana Data Model)<br />\r\n<strong>How Accessed</strong>: <a href=\"http://www.europeana.eu/portal/search.html?query=DATA_PROVIDER:%22Biblioteca%20Virtual%20del%20Patrimonio%20Bibliogr%C3%A1fico%22&amp;qf=TYPE:IMAGE\">Europeana Portal</a>, <a href=\"http://labs.europeana.eu/api/console/?function=search&amp;query=DATA_PROVIDER:%22Biblioteca%20Virtual%20del%20Patrimonio%20Bibliogr%C3%A1fico%22&amp;qf=TYPE:IMAGE\">API console</a></p>\r\n\r\n<p>Two datasets available through Europeana Labs stand out for researchers interested in cartography, historical geography and the history of map-making, as well as those working with cultural geography, urban studies and issues related to to the growing interest in spatial and geographic perspectives in the social sciences (“the spatial turn”).</p>\r\n\r\n<p><a href=\"http://labs.europeana.eu/data/Maps-and-Drawings-from-the-Cat%C3%A1logo-Colectivo-De-La-Red-De-Bibliotecas-De-Los-Archivos-Estatales/\">Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales</a> and <a href=\"http://labs.europeana.eu/data/Maps-and-Drawings-from-the-Biblioteca-Virtual-Del-Patrimonio-Bibliografico/\">Biblioteca Virtual del Patrimonio Bibliográfico</a> together total some 9,000 objects, including portolan charts, city plans, and drawings of buildings and fortifications. These maps span the period from the 16th to the 20th century, and they are all in the public domain.</p>\r\n\r\n<p><br />\r\n<img alt=\"Edinburgh from Civitates Orbis Terrarum, vol. III, p. 39; Universitäts- und Landesbibliothek Düsseldorf. Rights: Rights Reserved - Free Access.\" src=\"https://lh5.googleusercontent.com/2H5BpVjeY4vw1CbmXFtZSa0xETNearby4mQ9GfCe-RMirp-7pl3MP_PXuvbXCUviujVAz_gJJHvBjnEoz7wGd7f657b6ZKNVLlOrFqjTAtPqvXjFdI5_FyXXdtBJg94G2Ry7wTA\" title=\"Edinburgh from Civitates Orbis Terrarum, vol. III, p. 39; Universitäts- und Landesbibliothek Düsseldorf. Rights: Rights Reserved - Free Access.\" /><br />\r\n<em><a href=\"http://www.europeana.eu/portal/record/09428/urn_nbn_de_hbz_061_1_67166.html?query=Civitates+Orbis+Terrarum&amp;qf=edinburgh&amp;qt=false\">Edinburgh from Civitates Orbis Terrarum, vol. III, p. 39</a>; Universitäts- und Landesbibliothek Düsseldorf. Rights: <a href=\"http://www.europeana.eu/portal/rights/rr-f.html\">Rights Reserved - Free Access</a>. This map is found in the third volume of Georg Braun’s major cartographic work from 1588. Worth noting is his attention to detail in the oblique perspective (for instance of Edinburgh Castle) and the typical figures in the foreground. Braun’s Civitates arguably brought in a new era of cartography.</em></p>\r\n\r\n<p>The dataset from Biblioteca Virtual mainly contains maps from the 18th and 19th centuries – just over 1,000 and 2,000 maps, respectively. There are also 16th century maps (mainly portolan charts of Spanish and Dutch origin) and three of the six volumes of the wonderful 16th century Civitates Orbis Terrarum. This work contains more than 500 maps of cities from all around the world, 230 of which can be found in the available volumes.</p>\r\n\r\n<p><br />\r\n<img alt=\"Plano en perspectiva de la Villa de Aranda de Duero, Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales. Rights: Public Domain/No Copyright.\" src=\"https://lh3.googleusercontent.com/82ydVGU6SzeawDSAaHeHgDt3h80VOiGMFcWZ3sSejRsqsQgRIYOM5HAJXqbMc1-u3HMNB5Hzdm0NlDFyaNjvdsl-yruCROTNa7d20mM6NHDK51qxTGM-PN4Vez0O5m0h5gl4IXE\" title=\"Plano en perspectiva de la Villa de Aranda de Duero, Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales. Rights: Public Domain/No Copyright.\" /><br />\r\n<em><a href=\"http://www.europeana.eu/portal/record/2022701/oai_rebae_mcu_es_179381.html?start=1&amp;query=Plano+en+perspectiva+de+la+Villa+de+Aranda+de+Duero&amp;startPage=1&amp;qt=false&amp;rows=24\">Plano en perspectiva de la Villa de Aranda de Duero</a>, Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales. Rights: Public Domain/No Copyright. An interesting example of Renaissance mapmaking, of the town Aranda de Duero in present-day Castile and León. Created in 1503, it was submitted to the Royal Council of Castile together with information in connection with the opening of the Barrionuevo street.</em></p>\r\n\r\n<p>The maps in Braun’s Civitates are colourful, detailed bird’s-eye view pictures, offering a street plan and locations of important buildings like castles and cathedrals. They are what Ptolemy would have called chorographica, more artistic representations of a small region, rather than geographica, maps of countries or the world. The three volumes are scanned at high resolution (allowing for detailed analysis) and each page can be downloaded separately from the data provider.</p>\r\n\r\n<p>In addition to their cartographic appeal, these are works of great beauty, adorned with a variety of surround elements and illustrations that themselves offer analytical routes into the maps. They offer value to urban studies researchers, who may be following the development of the urban settlements, and to researchers who are negotiating the role of space and place in, for instance, the organisation and regulation of society.</p>\r\n\r\n<p>The other collection, the Catálogo Colectivo, contains over 5,000 maps and is dominated by 18th century content. Profile drawings of buildings, nautical charts, and road maps are some of the more special kinds of maps available. There is also sufficient 16th and 17th century material to study how maps have developed over time. The earliest object in the dataset, the 1503 Plano en perspectiva de la Villa de Aranda de Duero, uses an early approach to perspectival mapping and marks the starting point for a cavalcade of methods of mapping three-dimensional space onto a two-dimensional surface. Through the various maps, it is for instance possible to see how hachures develop from their early Renaissance form to the shading of the 19th century, and how land forms change from stylised representations to attempts at faithful renderings of the mapped landscape.</p>\r\n\r\n<p>These datasets, provided by state archives and libraries in Spain, offer possibilities to explore how space and place have been codified over the centuries, and how societies have been spatially organised. They allow us to examine the ways in which our three-dimensional surroundings have been reduced to two dimensions for various purposes – utilitarian as well as artistic. Finally, they provide a way to look at the past through the minds and pens of those who lived there.</p>','{\"file\":\"2015-04\\/4003273528-d78e05f042-b.jpeg\",\"title\":\"\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default','','Catálogo Colectivo de la Red de Bibliotecas de los Archivos Estatales',''),
	(2,'research-the-local-history-of-girona','2015-04-09 09:14:32','2015-04-16 13:43:24','2015-04-09 09:14:26',NULL,'',3,'published','Research the Local History of Girona','Europeana has a wealth of content available to researchers, both through its portal and its APIs. Europeana Research highlights this content and its research potential.','<p>This article by Eliza Papaki, Research Assistant at the <a href=\"http://www.dcu.gr\">Digital Curation Unit </a>, along with others in the series, focuses on collections of interest to the academic community.</p>','<p>One of the many collections available to researchers via the Europeana portal and an API is a rich collection of over 2,000 photographs and postcards presenting the <a href=\"http://labs.europeana.eu/data/art-and-life-on-postcards-and-photographs-from-girona/\">art and life of the Spanish city Girona </a>. It covers nearly a century of history (from 1839 to 1930) and a range of topics, from cork stopper factories to tombs of the clergy and city monuments.</p>\r\n\r\n<p><img alt=\"N.o 5.-Gerona.-Nuevas Ramblas., Rights:Unknown\" src=\"/files/Images/Europeana_Research/065397.jpg\" style=\"width: 450px; height: 294px;\" title=\"N.o 5.-Gerona.-Nuevas Ramblas., Rights:Unknown\" /></p>\r\n\r\n<p><em><a href=\"http://www.europeana.eu/portal/record/2024914/photography_ProvidedCHO_Ajuntament_de_Girona_065397.html?start=40&amp;query=europeana_collectionName%3A2024914*&amp;startPage=25&amp;qf=RIGHTS%3Ahttp%3A%2F%2Fcreativecommons.org%2Fpublicdomain%2Fmark%2F1.0%2F*&amp;qt=false&amp;rows=24\">N.o 5.-Gerona.-Nuevas Ramblas.</a>, Rights:Unknown.</em></p>\r\n\r\n<p>How could this interesting and rich collection be useful to researchers? Simply browsing this content can lead to observations on handwriting, clothing, financial occupation of the population or even urban architecture. It could thus be said that it is a collection with multiple interpretations which serves the research interests of a variety of disciplines. Researchers wandering through the large number of postcards can simply be inspired to set innovative research topics and questions for their essays or dissertations.</p>\r\n\r\n<p>Reconstructing the history of a city, its development through time and its traditions, can be an amazing adventure for local historians who wish to interpret the history of a local community. Dated in the 19th and 20th centuries, this collection serves as a ‘living testimony’ of the city of Girona which could not be approached through oral testimonies for example. On the other hand, since many of the postcards have written messages on them preserved during the digitization process, local historians may be lucky enough to reveal the microhistory of a citizen or family of Girona by transcribing these messages!</p>\r\n\r\n<p>There are a few considerations to be aware of when accessing this collection.</p>\r\n\r\n<p>First, despite the name ‘Girona’ in the title, not all results relate to the city of Girona. This is because the term ‘Girona’ relates to the fact that the images have been provided by the Spanish organisation <a href=\"http://www2.girona.cat/ca\" style=\"text-decoration:none;\"> Ajuntament de Girona</a>. Researchers will therefore find images of other destinations, including the French capital Paris, alongside the predominantly Spanish content.</p>\r\n\r\n<p>It is also important to note that the Ajuntament de Girona has provided all item descriptions in Spanish. Researchers who do not speak Spanish can overcome this barrier by using the translations available via the Europeana portal. Translations are also available when searching the collection, which means that English-speakers can refine their search by terms such as ‘bridge’ or ‘palace’, rather than ‘puente’ or ‘palacio’.</p>\r\n\r\n<p></p>','{\"file\":\"2015-04\\/1q0mw.jpg\",\"title\":\"\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default','','Ajuntament de Girona',''),
	(3,'european-correspondence-to-jacob-burckhardt-1842-1897','2015-04-15 08:16:04','2015-04-16 13:44:23','2015-04-15 07:48:48',NULL,'',4,'published','European Correspondence to Jacob Burckhardt (1842-1897)','Letters from the nineteenth-century cultural historian Jacob Buckhardt','<p>Letters from the nineteenth-century cultural historian Jacob Buckhardt</p>','<p>As part of the Digitised Manuscripts to Europeana project (DM2E), content related to the letters and correspondence of Jacob Buckhardt was presented to Europeana.</p>\r\n\r\n<p>Buckhardt was one of the first cultural historians. Operating across Europe, he had a signfiicant role in defining the discipline of art history and bringing scholarly analysis to broad artistic terms, notably in his study of the Renaissance. But, as the letters indicate, his interests were broader than history; politics and the effects of democracy, culture and the effects of a nascent modernism were two of his ongoing concerns.</p>\r\n\r\n<p><img alt=\"\" src=\"/files/2015-04/buckhardt-letter.jpg\" style=\"width: 394px; height: 525px;\" /></p>\r\n\r\n<p></p>\r\n\r\n<p><em>Buckhardt is asked once again for a portrait and a biographical sketch to be inserted in G. Könnecke’s «Bilderatlas zur Geschichte der deutschen Nationallitteratur», 1885, <a href=\"http://www.europeana.eu/portal/record/2048622/data_item_ecorr_burckhardtsource_118.html\">http://www.europeana.eu/portal/record/2048622/data_item_ecorr_burckhardtsource_118.html</a>, Staatsarchiv Basel, CC BY-NC-SA</em></p>\r\n\r\n<p>The letters are not cultural essays of course. They also deal with friends and family, requests from publishers, as in the example above where Buckhardt is asked to provide a portrait for a work on the history of German literature.</p>\r\n\r\n<p>There are <a href=\"http://www.europeana.eu/portal/search.html?query=Jacob_Burckhardt&amp;rows=24&amp;qf=DATA_PROVIDER%3A%22The+European+Correspondence+to+Jacob+Burckhardt%22&amp;qt=false\">497 letters realted to Buckhardt available via Europeana</a>. And, since they have a CC BY-NC-SA licence they can be reused non-commercially.</p>\r\n\r\n<p>This is amongst numerous collected presented to Europeana as part of DM2E. Other will be featured on Europeana Research in coming months</p>','{\"file\":\"2015-04\\/api.jpg\",\"title\":\"Letter to Jacob Buckhardt, 1885\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default','','',''),
	(4,'a-holiday-in-wales','2015-04-15 12:38:50','2015-04-15 13:17:18','2015-04-15 12:30:15',NULL,'',9,'draft','A Holiday in Wales?','Europeana has a wealth of content available to researchers, both through its portal and its APIs. Europeana Research highlights this content and its research potential.','<p>Europeana has a wealth of content available to researchers, both through its portal and its APIs. Europeana Research highlights this content and its research potential.</p>','<p>By Owain Roberts, Research Associate in Digital Collections at <a href=\"http://www.llgc.org.uk/\" target=\"_blank\">National Library of Wales</a></p>\r\n\r\n<p><strong>Collection Title</strong>: Drawings and sketches from the National Library of Wales<br />\r\n<strong>Source</strong>: National Library of Wales<br />\r\n<strong>Licence for metadata</strong>: CC0<br />\r\n<strong>Licence for Content</strong>: CC BY-SA<br />\r\n<strong>Data Format</strong>: Image<br />\r\n<strong>Metadata Format</strong>: EDM (Europeana Data Model)<br />\r\n<strong>How Accessed</strong>: <a href=\"http://europeana.eu/portal/search.html?query=europeana_collectionName%3A08806*&amp;rows=24\" target=\"_blank\">Europeana Portal</a>, <a href=\"http://labs.europeana.eu/api/console/?function=search&amp;query=europeana_collectionName%3A08806*&amp;rows=24\" target=\"_blank\">API console</a></p>\r\n\r\n<p>All of us enjoy some time off to go on holiday every now and again don’t we? Nowadays, smartphones allows us to photograph every step of the way and share them instantly with friends around the world. But before smartphones you had to remember to pack your camera otherwise you’d have no record of the sights and sounds that you experienced.</p>\r\n\r\n<p><img alt=\"\" src=\"/files/Images/Europeana_Research/wales2.jpg\" style=\"width: 600px; height: 545px;\" /><br />\r\n<em>Sketches in England, Scotland and Wales, Alfred W. Williams, <a href=\"http://www.europeana.eu/portal/record/08806/cgi_bin_gw_chameleon_lng_en_host_localhost_9901_DEFAULT_search_KEYWORD_function_CARDSCR_u1_12101_t1_004447292.html?start=576&amp;query=europeana_collectionName%3A08806*&amp;startPage=553&amp;qt=false&amp;rows=24\" target=\"_blank\">National Library of Wales</a>, CC BY SA.</em></p>\r\n\r\n<p>But how did people do it before they had cameras? They drew sketches. The National Library of Wales has contributed <a href=\"http://labs.europeana.eu/data/drawings-and-sketches-from-the-national-library-of-wales/\" target=\"_blank\">a collection of drawing volumes</a> to Europeana, which includes around 600 items. This collection contains a wide variety of material, from the amateur sketches of wealthy travellers to the field sketchbooks of professional artists which a user can share and adapt for any purpose (CC-BY-SA licensing rights).</p>\r\n\r\n<p>The collection covers the period from the 18th century to the 20th century but the bulk of the Library\'s collection dates from the 19th century. Amongst the 18th century volumes the most important are the work of Alexander Cozens (1717-1786) and his son John Robert (1752-1797), P. J. de Loutherbourg (1748-1812), Moses Griffith (1749-1819), and Thomas Jones, Pencerrig (1742-1803).</p>\r\n\r\n<p>The volumes are mainly filled with landscapes of Wales, many following a particular topographical route. It became fashionable for tourists to illustrate their tours with their own sketches and so the collection contains volumes of such sketches. The works of John Parker (1798-1860) and Edward Pryce Owen (1788-1863) are very good examples of this.</p>\r\n\r\n<p><img alt=\"\" src=\"/files/Images/Europeana_Research/wales1.jpg\" style=\"width: 600px; height: 441px;\" /><br />\r\nSketchbook of views, figures and fishing, Calvert Richard Jones, <a href=\"http://www.europeana.eu/portal/record/08806/cgi_bin_gw_chameleon_lng_en_host_localhost_9901_DEFAULT_search_KEYWORD_function_CARDSCR_u1_12101_t1_006017838.html?start=48&amp;query=europeana_collectionName%3A08806*&amp;startPage=25&amp;qf=jones&amp;qt=false&amp;rows=24\" target=\"_blank\">National Library of Wales</a>, CC BY SA.<br />\r\n<br />\r\nNot only visually very beautiful, the collection provides a rich resource for art historians interested in British traditions of landscape painting, and the depiction of natural space. Researchers with an interest in the history of tourism and the evolution of the Grand Tour can also discover items relating to a number of popular destinations including Venice, the Riviera and Switzerland.</p>\r\n\r\n<p>Apps that could be used with this collection:</p>\r\n\r\n<ul>\r\n    <li><a href=\"http://neatline.org/\">Neatline</a> – for displaying the items in a timeline and spatially (possibly tracking the topographical route)</li>\r\n    <li><a href=\"http://labs.europeana.eu/apps/digital-storytelling-prototype/\" target=\"_blank\">Digital Storytelling Prototype</a> – to narrate one of the topographical routes taken</li>\r\n</ul>','{\"file\":\"Images\\/Europeana_Research\\/wales2.jpg\",\"title\":\"\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default','','',''),
	(5,'portable-antiquities-and-other-historical-objects-from-the-neolithic-until-the-middle-ages','2015-04-16 08:36:58','2015-04-16 10:08:20','2015-04-16 08:26:05',NULL,'',9,'draft','Portable antiquities and other historical objects from the Neolithic until the Middle Ages','Europeana has a wealth of content available to researchers, both through its portal and its APIs. Europeana Research highlights this content and its research potential. This article by Agiatis Bernardou, Researcher at Digital Curation Unit R.C. ‘Athena’, focuses on a collection of antiquities.','<p>Europeana has a wealth of content available to researchers, both through its portal and its APIs. Europeana Research highlights this content and its research potential. This article by Agiatis Bernardou, Researcher at Digital Curation Unit R.C. ‘Athena’, focuses on a collection of antiquities.</p>','<p><strong>Collection Title</strong>: Portable Antiquities - historical objects from the Neolithic until the Middle Ages<br />\r\n<strong>Source</strong>: The British Museum and The Portable Antiquities Scheme<br />\r\n<strong>Licence for metadata</strong>: CC0<br />\r\n<strong>Licence for Content</strong>: CC BY-SA<br />\r\n<strong>Data Format</strong>: Image<br />\r\n<strong>Metadata Format</strong>: EDM (Europeana Data Model)<br />\r\n<strong>How Accessed</strong>: <a href=\"http://europeana.eu/portal/search.html?query=europeana_collectionName%3A2022324*&amp;rows=24&amp;qf=RIGHTS%3Ahttp%3A%2F%2Fcreativecommons.org%2Flicenses%2Fby-sa%2F*\" target=\"_blank\">Europeana Portal</a>, <a href=\"http://labs.europeana.eu/api/console/?function=search&amp;query=europeana_collectionName%3A2022324*&amp;rows=24&amp;qf=RIGHTS%3Ahttp%3A%2F%2Fcreativecommons.org%2Flicenses%2Fby-sa%2F*\" target=\"_blank\">API console</a></p>\r\n\r\n<p><img alt=\"\" src=\"/files/Images/Europeana_Research/medievalcoins.jpg\" style=\"width: 600px; height: 375px;\" /></p>\r\n\r\n<p><em>Silver groat of Henry VIII, York mint. 3rd coinage,<a href=\"http://www.europeana.eu/portal/record/2022324/226016.html\" target=\"_blank\">The British Museum and The Portable Antiquities Scheme</a>, CC BY-SA.</em></p>\r\n\r\n<p>Unsurprisingly, <a href=\"http://labs.europeana.eu/data/portable-antiquities-historical-objects-from-the-neolithic-until-the-middle-ages/\" target=\"_blank\">a collection on portable antiquities and other historical objects from the Neolithic until the Middle Ages</a> could be of general interest to the public and to particular research communities such as archaeologists, historians, numismatic experts and art historians for academic use. The chronological and thematic extent of this collection from the British Museum and the Portable Antiquities Scheme can be seen as advantageous, because many of the movable finds can be found in context. Disadvantageous however is that this context is at times unclear, if not totally absent. Take, for example the post-Medieval items of the collection: a researcher on that era or, for that matter, on metal objects of the past would benefit greatly from the variety of coins, weights and brooches; however, the mere presence of Mesolithic axe heads in the same collection reduces its potential for high-level academic use.</p>\r\n\r\n<p>The discrepancy between the stated number of objects in Europeana Labs (more than 290,000 items) and the Europeana portal (about 375,000 items) could be easily overcome and would not in any way disturb the research process. On the contrary, the temporal parameter of the collection (”You may enter only years in this field…”), does not facilitate the work of the researchers and would make the navigation through this collection extremely hard, since this parameter can not be valid for the time between the Neolithic and Medieval periods. For instance, in the case of a post-Medieval axe, the date of creation is stated as 1500-1950. It is easy to understand the issue of dating such findings – and there is usually more than one reason that the dates are not precise – however such a dating combined with the low resolution of the image, renders the item highly improbable to be the object of advanced research in the Arts and Humanities where the level of detail makes every difference. Having said that, though, one could see how this digital resource could be of use for educational purposes.</p>\r\n\r\n<p>Although the resolution of the images is not always consistent and depictions on coins, for example, are not easily discernible, the licensing of the collection [CC BY-SA] allowing for sharing and conditionally remixing, supports and facilitates research on a collaborative level.</p>\r\n\r\n<p>In conclusion, the collection on portable antiquities and other historical objects from the Neolithic until the Middle Ages could be seen as an entry-point to the world of archaeological, historical and art-historical research of the periods, as well as a valuable set of resources for the general, history-loving public.</p>\r\n\r\n<p></p>','{\"file\":\"Images\\/Europeana_Research\\/medievalcoins.jpg\",\"title\":\"\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default','','','');

/*!40000 ALTER TABLE `bolt_collections` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_content_changelog
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_content_changelog`;

CREATE TABLE `bolt_content_changelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `username` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ownerid` int(11) DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contenttype` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `contentid` int(11) NOT NULL,
  `mutation_type` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `diff` longtext COLLATE utf8_unicode_ci NOT NULL,
  `comment` varchar(150) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `IDX_D51B58EEAA9E377A` (`date`),
  KEY `IDX_D51B58EEF85E0677` (`username`),
  KEY `IDX_D51B58EE75DAD987` (`ownerid`),
  KEY `IDX_D51B58EE745E1826` (`contenttype`),
  KEY `IDX_D51B58EEE625AE99` (`contentid`),
  KEY `IDX_D51B58EEB0AEEF39` (`mutation_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table bolt_cron
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_cron`;

CREATE TABLE `bolt_cron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interim` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `lastrun` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CD38E123615F8869` (`interim`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table bolt_footers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_footers`;

CREATE TABLE `bolt_footers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `datecreated` datetime NOT NULL,
  `datechanged` datetime NOT NULL,
  `datepublish` datetime DEFAULT NULL,
  `datedepublish` datetime DEFAULT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `ownerid` int(11) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` longtext COLLATE utf8_unicode_ci NOT NULL,
  `socialmedia` longtext COLLATE utf8_unicode_ci NOT NULL,
  `linklist_left` longtext COLLATE utf8_unicode_ci NOT NULL,
  `linklist_right` longtext COLLATE utf8_unicode_ci NOT NULL,
  `mission` longtext COLLATE utf8_unicode_ci NOT NULL,
  `linklist_other` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E2E0E075989D9B62` (`slug`),
  KEY `IDX_E2E0E075AFBA6FD8` (`datecreated`),
  KEY `IDX_E2E0E075BE74E59A` (`datechanged`),
  KEY `IDX_E2E0E075A5131421` (`datepublish`),
  KEY `IDX_E2E0E075B7805520` (`datedepublish`),
  KEY `IDX_E2E0E0757B00651C` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_footers` WRITE;
/*!40000 ALTER TABLE `bolt_footers` DISABLE KEYS */;

INSERT INTO `bolt_footers` (`id`, `slug`, `datecreated`, `datechanged`, `datepublish`, `datedepublish`, `username`, `ownerid`, `status`, `title`, `image`, `socialmedia`, `linklist_left`, `linklist_right`, `mission`, `linklist_other`)
VALUES
	(1,'slug-e1i5f9','2015-03-04 15:20:41','2015-04-16 13:46:08','2015-03-04 15:14:06',NULL,'',3,'published','Footer Europeana Labs','{\"file\":\"2015-04\\/4xpwp.jpeg\",\"title\":\"Europeana\"}','<h4>Find us elsewhere:</h4>\r\n\r\n<p><a href=\"https://twitter.com/eurresearch\"><svg class=\"icon icon-twitter\"> <use xlink:href=\"#icon-twitter\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"> </use> </svg> </a></p>','<h4 class=\"title\">More info</h4>\r\n\r\n<ul>\r\n    <li><a href=\"/blogposts\">Blog</a></li>\r\n</ul>','','<p><em>We transform the world with culture.</em></p>','');

/*!40000 ALTER TABLE `bolt_footers` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_homepage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_homepage`;

CREATE TABLE `bolt_homepage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `datecreated` datetime NOT NULL,
  `datechanged` datetime NOT NULL,
  `datepublish` datetime DEFAULT NULL,
  `datedepublish` datetime DEFAULT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `ownerid` int(11) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bannerimage` longtext COLLATE utf8_unicode_ci NOT NULL,
  `imageattribution` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `imagelicense` longtext COLLATE utf8_unicode_ci NOT NULL,
  `brandcolour` longtext COLLATE utf8_unicode_ci NOT NULL,
  `brandopacity` longtext COLLATE utf8_unicode_ci NOT NULL,
  `brandlocation` longtext COLLATE utf8_unicode_ci NOT NULL,
  `bannertext` longtext COLLATE utf8_unicode_ci NOT NULL,
  `bannerlink` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subtitle` longtext COLLATE utf8_unicode_ci NOT NULL,
  `callout_1` longtext COLLATE utf8_unicode_ci NOT NULL,
  `callout_2` longtext COLLATE utf8_unicode_ci NOT NULL,
  `callout_3` longtext COLLATE utf8_unicode_ci NOT NULL,
  `callout_6` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9D9C7FD3989D9B62` (`slug`),
  KEY `IDX_9D9C7FD3AFBA6FD8` (`datecreated`),
  KEY `IDX_9D9C7FD3BE74E59A` (`datechanged`),
  KEY `IDX_9D9C7FD3A5131421` (`datepublish`),
  KEY `IDX_9D9C7FD3B7805520` (`datedepublish`),
  KEY `IDX_9D9C7FD37B00651C` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_homepage` WRITE;
/*!40000 ALTER TABLE `bolt_homepage` DISABLE KEYS */;

INSERT INTO `bolt_homepage` (`id`, `slug`, `datecreated`, `datechanged`, `datepublish`, `datedepublish`, `username`, `ownerid`, `status`, `title`, `bannerimage`, `imageattribution`, `imagelicense`, `brandcolour`, `brandopacity`, `brandlocation`, `bannertext`, `bannerlink`, `subtitle`, `callout_1`, `callout_2`, `callout_3`, `callout_6`)
VALUES
	(1,'slug-0j6tac','2015-03-03 08:54:02','2015-04-16 13:42:48','2015-03-03 08:52:43',NULL,'',4,'published','Europeana Research','{\"file\":\"2015-04\\/tumblr-mehchl6uuc1qmod23o1-1280.jpeg\",\"title\":\"\"}','<a href=\"http://www.europeana.eu/portal/record/9200105/BibliographicResource_3000006127624.html\">Young boys hand out newspapers to the waiting crowds,</a> Wellcome Library','CC-BY','brand-colour-site','brand-opacity50','brand-bottomright','<h2>Find out about our <a href=\"http://research.europeana.eu/about-us/about-europeana-research\">forthcoming plans</a> and <a href=\"https://twitter.com/eurresearch\">follow us on Twitter</a></h2>','','<p>Europeana Research - Liberating Cultural Heritage for Use in Research</p>','<p>Trala</p>','<p>Share</p>','<p>Use</p>','<h3>Featured collections</h3>');

/*!40000 ALTER TABLE `bolt_homepage` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_locations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_locations`;

CREATE TABLE `bolt_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `datecreated` datetime NOT NULL,
  `datechanged` datetime NOT NULL,
  `datepublish` datetime DEFAULT NULL,
  `datedepublish` datetime DEFAULT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `ownerid` int(11) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `geolocation` longtext COLLATE utf8_unicode_ci NOT NULL,
  `europeana_place` tinyint(1) NOT NULL DEFAULT '0',
  `europeana_office` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_4FD8BE01989D9B62` (`slug`),
  KEY `IDX_4FD8BE01AFBA6FD8` (`datecreated`),
  KEY `IDX_4FD8BE01BE74E59A` (`datechanged`),
  KEY `IDX_4FD8BE01A5131421` (`datepublish`),
  KEY `IDX_4FD8BE01B7805520` (`datedepublish`),
  KEY `IDX_4FD8BE017B00651C` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_locations` WRITE;
/*!40000 ALTER TABLE `bolt_locations` DISABLE KEYS */;

INSERT INTO `bolt_locations` (`id`, `slug`, `datecreated`, `datechanged`, `datepublish`, `datedepublish`, `username`, `ownerid`, `status`, `title`, `geolocation`, `europeana_place`, `europeana_office`)
VALUES
	(1,'main-europeana-office','2015-03-05 15:44:21','2015-03-05 15:44:34','2015-03-05 15:43:42',NULL,'',3,'published','Main Europeana Office','{\"address\":\"Koningin Julianaplein 10, 2595 AA The Hague Netherlands\",\"latitude\":\"52.081561\",\"longitude\":\"4.3236\",\"formatted_address\":\"Koningin Julianaplein 10, 2595 AA Den Haag, Netherlands\"}',0,1);

/*!40000 ALTER TABLE `bolt_locations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_log_change
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_log_change`;

CREATE TABLE `bolt_log_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ownerid` int(11) DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contenttype` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `contentid` int(11) NOT NULL,
  `mutation_type` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `diff` longtext COLLATE utf8_unicode_ci NOT NULL,
  `comment` varchar(150) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `IDX_946F972AA9E377A` (`date`),
  KEY `IDX_946F97275DAD987` (`ownerid`),
  KEY `IDX_946F972745E1826` (`contenttype`),
  KEY `IDX_946F972E625AE99` (`contentid`),
  KEY `IDX_946F972B0AEEF39` (`mutation_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table bolt_log_system
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_log_system`;

CREATE TABLE `bolt_log_system` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `message` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `ownerid` int(11) DEFAULT NULL,
  `requesturi` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `route` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `context` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `source` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_805C16D99AEACC13` (`level`),
  KEY `IDX_805C16D9AA9E377A` (`date`),
  KEY `IDX_805C16D975DAD987` (`ownerid`),
  KEY `IDX_805C16D9E25D857E` (`context`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table bolt_pages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_pages`;

CREATE TABLE `bolt_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `datecreated` datetime NOT NULL,
  `datechanged` datetime NOT NULL,
  `datepublish` datetime DEFAULT NULL,
  `datedepublish` datetime DEFAULT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `ownerid` int(11) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `intro` longtext COLLATE utf8_unicode_ci NOT NULL,
  `teaser` longtext COLLATE utf8_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8_unicode_ci NOT NULL,
  `teaser_image` longtext COLLATE utf8_unicode_ci NOT NULL,
  `secondary_mail` tinyint(1) NOT NULL DEFAULT '0',
  `hide_list` tinyint(1) NOT NULL DEFAULT '0',
  `filelist_files` longtext COLLATE utf8_unicode_ci NOT NULL,
  `filelist_downloads` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hide_related` tinyint(1) NOT NULL DEFAULT '0',
  `hide_related_section` tinyint(1) NOT NULL DEFAULT '0',
  `listtitle` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `imagelist` longtext COLLATE utf8_unicode_ci NOT NULL,
  `liststyle` longtext COLLATE utf8_unicode_ci NOT NULL,
  `support_navigation` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_31AF1BC8989D9B62` (`slug`),
  KEY `IDX_31AF1BC8AFBA6FD8` (`datecreated`),
  KEY `IDX_31AF1BC8BE74E59A` (`datechanged`),
  KEY `IDX_31AF1BC8A5131421` (`datepublish`),
  KEY `IDX_31AF1BC8B7805520` (`datedepublish`),
  KEY `IDX_31AF1BC87B00651C` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_pages` WRITE;
/*!40000 ALTER TABLE `bolt_pages` DISABLE KEYS */;

INSERT INTO `bolt_pages` (`id`, `slug`, `datecreated`, `datechanged`, `datepublish`, `datedepublish`, `username`, `ownerid`, `status`, `title`, `intro`, `teaser`, `body`, `teaser_image`, `secondary_mail`, `hide_list`, `filelist_files`, `filelist_downloads`, `hide_related`, `hide_related_section`, `listtitle`, `imagelist`, `liststyle`, `support_navigation`)
VALUES
	(21,'engaging-with-europeana','2015-03-04 14:55:47','2015-04-02 10:48:19','2015-03-04 14:41:51',NULL,'',3,'published','Engaging with Europeana','As part of the Europeana Cloud project, Agiatis Benardou (Digital Curation Unit, Athens) and Vicky Garnett (Trinity College Dublin) have been exploring Europeana for academic scholarship.','<p>A perspective from the research community.</p>','<p>The Europeana portal in its current form has been available to researchers now for nearly 7 years, and in that time has provided access to collections from Galleries, Libraries, Archives and Museums (GLAMs) across Europe. Some of its main strengths are clear frameworks for <a href=\"http://pro.europeana.eu/get-involved/europeana-ipr/europeana-licensing-framework\">licensing</a> and <a href=\"http://pro.europeana.eu/share-your-data/data-guidelines\">metadata</a> and the ability to create massive standardised open datasets from its huge network of cultural institutions.</p>\r\n\r\n<p>Europeana recently published the details of its content priorities for Humanities and the Social Sciences, (<a href=\"http://pro.europeana.eu/files/Europeana_Professional/Projects/Project_list/Europeana_Cloud/Deliverables/D1.4%20Content%20priorities%20for%20Humanities%20and%20Social%20Sciences%20research%20communities.pdf\">the full document outlining content priorities is available here</a>) in which a survey of the 100 largest collections within Europeana was conducted. An outcome of this work was that, while the variety of artefacts and items within the collections are vast and varied, a number of recurring themes presented themselves.</p>\r\n\r\n<p>Social historians, for example, would find great use from the extensive collections of newspapers, photographs, political pamphlets, and census records that are available. Botanists would certainly be able to make interesting inferences from the images of preserved flowers from Kew Gardens. Sociology and Middle East studies majors might make use of the numbers of photographs from kibbutzim that span the later 20th century. The potential for use within these collections is wide open, and the Europeana Cloud project is investigating how researchers might gain greater access to these collections via its Europeana Research platform.</p>\r\n\r\n<h3>Where can Europeana work better for the research community ?</h3>\r\n\r\n<p>Over the course of the Europeana Cloud project so far, we have been investigating the potential uses for the collections for researchers within the Humanities and Social Sciences. This has been done through web surveys and through the Expert Fora that were hosted in the first 12 months of the project, which brought together researchers from within those fields to discuss both the content and the potential tools that could be used with that content. Furthermore, case studies have been devised around the needs of researchers in Philosophy and Musicology.</p>\r\n\r\n<p>Τhree core problems for the researchers in philosophy and digital humanities were identified:</p>\r\n\r\n<ul>\r\n    <li>Problems with navigating and identifying relevant (digital) content and with building corpora;</li>\r\n    <li>Lack of user-friendly tools for conducting fine-grained textual research;</li>\r\n    <li>Lack of appropriate tools and infrastructure that allow members of research groups to work collaboratively.</li>\r\n</ul>\r\n\r\n<p>Four identified core problems for musicologists include:</p>\r\n\r\n<ul>\r\n    <li>Problems involving data creation;</li>\r\n    <li>Lack of music scores;</li>\r\n    <li>Information exchange and linking of data;</li>\r\n    <li>Retrieval and analysis of contextual information.</li>\r\n</ul>\r\n\r\n<h3>Using the Europeana API</h3>\r\n\r\n<p>As well as the portal, Europeana provides access to collections of data via a RESTful API. This is useful for researchers who are proficient in using APIs and the resulting data, but as we have found through our investigations into API use among the GLAM community, an API is only as good as the metadata to which it is linked, and is only as accessible as the developers, and indeed the associated documentation, will allow.</p>\r\n\r\n<p>Various apps have already been developed using the current Europeana API. For example, the creator of ‘Culture Collage’ (<a href=\"http://www.zenlan.com/collage\">http://www.zenlan.com/collage</a>/) created an interface that allows the user to search for images of items made available by multiple aggregators, such as the DPLA and Trove, as well as Europeana. Serendip-o-matic (<a href=\"http://serendipomatic.org\">http://serendipomatic.org</a>/) works on a similar principle of searching a multitude of data sources, including Europeana, by first reviewing text that has been entered into the search field by the user. It then selects random phrases within that text, and uses them as search terms to identify and bring up items from the collections available. In both cases there are still items which are presented to the user that either do not have complete data, or an image associated and therefore might not be useable.</p>\r\n\r\n<h3>Recommendations for Europeana Research</h3>\r\n\r\n<p>The Expert Fora produced a number of recommendations. The overall improvement of metadata was one, and a related recurring proposition was<strong> the development of a \'read/write’ API</strong> to replace the currently read-only approach, so that the annotation and enrichment of the available data can be allowed by third parties.</p>\r\n\r\n<p><strong>Build specific, re-usable corpora to provide critical mass in certain areas</strong>. Researchers noted the breadth of the data aggregated in Europeana, but this contrasted with their need for narrow but richer dataset. Any Europeana Research content strategy should focus on particular areas where they can build and develop datasets (ideally including content as well as metadata) that serve different use cases.</p>\r\n\r\n<p><strong>Continuing to develop relationships with research infrastructures to ensure the re-use of data</strong>. To this end, Europeana is working closely with DARIAH and CLARIN, not just in order to ensure its data is reused in researchers’ workflows but also because the expertise in building specific tools lies not with Europeana itself, but in research communities that make up DARIAH and CLARIN.</p>\r\n\r\n<p>This feeds neatly into Europeana’s aim for Europeana Research to produce a ‘platform, not a portal’, and provide greater usability for researchers particularly within the Humanities and Social Sciences.</p>\r\n\r\n<p>By following these recommendations, Europeana Research aims to become the conduit that brings researchers within HEIs and Research Infrastructures closer to the data available through the Galleries, Libraries, Archives and Museums throughout the continent.</p>\r\n\r\n<p></p>\r\n\r\n<p></p>','{\"file\":\"Images\\/Teaser_images\\/europeana-research-bg.png\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default',''),
	(22,'the-current-europeana-dataset','2015-03-04 15:13:42','2015-03-26 11:37:43','2015-03-04 15:04:25',NULL,'',3,'published','The Current Europeana Dataset','Where does it come from?','<p>This explains how Europeana brings together the digitised content of over 3,300 of Europe’s galleries, libraries, museums, archives and audio-visual collections.</p>','<h3>The Europeana Dataset</h3>\r\n\r\n<p>The Europeana Dataset brings together the digitised content of Europe’s galleries, libraries, museums, archives and audio-visual collections. Currently, the portal provides integrated access to over 40 million books, films, paintings, museum objects and archival documents from over 3,000 data providers.</p>\r\n\r\n<p>The data can currently be searched <a href=\"http://www.europeana.eu/portal/\">via the portal</a> or <a href=\"http://labs.europeana.eu/api/\">queried via an API</a>. There is also an experimental <a href=\"http://europeana.ontotext.com/\">SPARQL endpoint</a></p>\r\n\r\n<h3>About the collection: selection policy</h3>\r\n\r\n<p>The current content policy of the Europeana Foundation is geared towards the aggregation of as much digital heritage metadata of European origin as possible. Europeana aggregates only metadata and thumbnails; they do not store content itself but rather links to content held by data providers. In 2011, the Europeana Foundation for the first time aggregated user-generated (memorabilia and stories) content with the projects Europeana 1914-1918 and Europeana 1989; however, this constitutes a small part of the collection.</p>\r\n\r\n<h3>About the dataset: aggregation process</h3>\r\n\r\n<p>The Europeana Foundation has around 40 employees, and is hosted by the National Library of the Netherlands in The Hague; therefore it cannot interact directly with all 3,000+ institutions at every stage. The Foundation makes use of a network of partner aggregators who collect, format and manage metadata from multiple data providers, providing services such as offering their own portal and acting as data provider to Europeana.</p>\r\n\r\n<p>The Foundation works with three types of aggregators: national/regional, domain-level (libraries, museums) and theme-focused (Europeana Fashion, European Film Gateway). The largest domain-level aggregator for national and research libraries from Europe is The European Library, the biggest data provider to Europeana. There are also specific aggregators for archives (Apex), and film and television (EFG, EU SCreen).</p>\r\n\r\n<p>A full list of aggregators is available on the Europeana Pro.</p>\r\n\r\n<h3>Harmonisation of the metadata</h3>\r\n\r\n<p>The metadata is collected from various types of aggregators from across Europe. Many different metadata standards are used - therefore the metadata needs to be harmonised. Each of the aggregators converts the native format into a single interoperable format. At first, the Europeana Semantic Elements model was used, an extended Dublin Core model, as an interoperable standard metadata. This provided a first step for making heterogeneous data compatible, but meant sacrificing some of the individual richness of particular data formats.</p>\r\n\r\n<p>This was superseded by the <a href=\"http://pro.europeana.eu/share-your-data/data-guidelines/edm-documentation\">Europeana Data Model</a>. This is a richer model, allowing for domain-specific metadata standards to be incorporated without a loss of information, providing greater relationship to the semantic web as well as providing meaningful links to Europe’s cultural heritage data.</p>\r\n\r\n<p>The Europeana Foundation enriches the metadata they receive from aggregators the data with controlled lists of names, places and subjects.</p>\r\n\r\n<h3>Licencing and Re-use</h3>\r\n\r\n<p>All standardised metadata made available via Europeana is marked as Creative Commons 0. This means the owners of the metadata have waived all rights in the data, and it can be used for any purpose, eg for research but also for commercial purposes.</p>\r\n\r\n<p>The Europeana Foundation also uses 13 standardised rights statements describing copyright, access and (re-)use of the content that its metadata links to. Rights statements can be split into four categories:</p>\r\n\r\n<ul>\r\n    <li>Public Domain - where copyright does not exist, has expired or has been waived and best practice guidelines for use apply</li>\r\n    <li>Creative Commons licences - where the rights holder grants permission to apply one of the six Creative Commons licences</li>\r\n    <li>Rights Reserved - where access to the objects is provided, and additional permissions are required for re-use</li>\r\n    <li>Unknown Status - where the rights are unknown, or the object is a legally recognised Orphan Work</li>\r\n</ul>\r\n\r\n<p>Within the (non-commercial) research domain, any content from a museum, library or other data provider with a Public Domain mark or a Creative Commons Licence can be used. The precise nature of this re-use (eg whether the work can be edited) depend on the exact licence being applied.</p>\r\n\r\n<p>On the Europeana portal, The rights statements are accessible by clicking on the object you want to (re-)use. By clicking through the rights statement accompanying any object, you will access a webpage that describes the rights and permissions in more detail.</p>\r\n\r\n<p></p>\r\n\r\n<p><em>Alastair Dunning, The Europeana Foundation</em></p>\r\n\r\n<p><em>Ingeborg Verspille, Consortium of Europeana Research Libraries</em></p>','{\"file\":\"Images\\/Teaser_images\\/europeana-research-bg.png\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default',''),
	(24,'apis','2015-03-17 09:43:24','2015-04-08 13:21:06','2015-03-17 09:42:25',NULL,'',4,'published','APIs','','<p>The Europeana APIs allow you to search and retrieve the contents of our database for use in your own applications.</p>','<p><br />\r\nThe Europeana Foundation currently offer two APIs for use. The first is a REST-API that is suited for dynamic search and retrieval of our data. This API offers exactly the same data as the Europeana Portal for end-users and in many ways the Portal can be viewed as an advanced API-implementation.</p>\r\n\r\n<p>The second API is more experimental and supports download of complete datasets and advanced semantic search and retrieval of our data via the SPARQL query language. The Linked Open Data Downloads and SPARQL-endpoint currently includes only a sub-set of all Europeana data, about 20 million of the c.40m records. Europeana is working on changing that situation and ensure the Linked Open Data service is always up to date.</p>\r\n\r\n<p><a href=\"http://labs.europeana.eu/api/\">For full details on the API see the appropriate page on Europeana Labs</a></p>','{\"file\":\"Images\\/Teaser_images\\/europeana-research-bg.png\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default',''),
	(25,'roadmap','2015-03-17 10:09:16','2015-04-14 11:19:54','2015-03-17 10:01:59',NULL,'',4,'published','Roadmap for Europeana Research','','<p>What will Europeana Research be doing in 2015 ?</p>','<p>In 2015, we will undertake the following pieces of work. Please get in touch via <a href=\"https://twitter.com/eurresearch\">Twitter</a> or <a href=\"http://mailto:alastair.dunning@europeana.eu\">email </a> if you have comments, ideas, suggestions</p>\r\n\r\n<ul>\r\n    <li><strong>Exploring how full text and images from the Europeana Newspapers project can be made available for re-use</strong></li>\r\n</ul>\r\n\r\n<p>The <a href=\"http://www.theeuropeanlibrary.org/tel4/newspapers\">Europeana Newsapers</a> project had made several million pages of text and images available in the public domain. We will be exploring how the content can be re-used by the research community</p>\r\n\r\n<ul>\r\n    <li><strong>Building a full-text API based on Europeana Newspapers</strong></li>\r\n</ul>\r\n\r\n<p>Based on the above newspapers content, Europeana Research will build a full text API and make it available for usage</p>\r\n\r\n<ul>\r\n    <li><strong>Developing student modules for teaching usage of the Europeana data / API</strong></li>\r\n</ul>\r\n\r\n<p>We will be working with the DARIAH network (Digital Research Infrastructure for the Arts and Humanities) to build teaching modules that explain the usage of the Europeana API</p>\r\n\r\n<ul>\r\n    <li><strong>Highlight other collections of interest to the research community</strong></li>\r\n</ul>\r\n\r\n<p>Our sister service Europeana Labs makes other collections available via an API. Europeana Research will highlight some of the most useful collections for re-use in research.</p>\r\n\r\n<ul>\r\n    <li><strong>Continuing to gather user requirements for Europeana Research</strong></li>\r\n</ul>\r\n\r\n<p>Europeana Research will continue to evolve. As part of the Europeana Cloud project, user requirements and feedback will be sought from research communities and infrastructures.</p>\r\n\r\n<ul>\r\n    <li><strong>Developing a Content Strategy for Europeana Research</strong></li>\r\n</ul>\r\n\r\n<p>As part of the Europeana Cloud project, a content strategy is being developed to guide the type of content that Europeana can make available to the research community. With DARIAH and CLARIN (Common Language Resources and Technology Infrastructure), Europeana will also form an advisory board to guide future work.</p>','{\"file\":\"Images\\/Europeana_Research\\/ryh-1402-15.jpg\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default',''),
	(26,'horizon-2020-and-other-project-proposals','2015-03-19 10:08:08','2015-04-09 09:24:07','2015-03-19 10:07:11',NULL,'',4,'published','Horizon 2020 and other project proposals','Working with Europeana offers numerous benefits for research projects, especially in the humanities and social sciences.','<p>Working with Europeana offers numerous benefits for research projects in the humanities and social sciences.</p>','<p>For potential research projects making use of European cultural heritage, Europeana provides a number of advantages :</p>\r\n\r\n<p><strong>A networking point for the cultural heritage sector</strong></p>\r\n\r\n<ul>\r\n    <li>Via its network Europeana has contact with over 3,300 museums, libraries and archives from all EU members states and beyond.</li>\r\n</ul>\r\n\r\n<p><strong>An instrument for aggregating data from across Europe</strong></p>\r\n\r\n<ul>\r\n    <li>Europeana has developed the most advanced aggregation infrastructure in cultural heritage. Through partners such as ApEx, Eu SCreen and the European Library, Europeana has the means to collect data from digitised and non-digitised collections throughout Europe.</li>\r\n</ul>\r\n\r\n<p><strong>A means of standardising disparate data</strong></p>\r\n\r\n<ul>\r\n    <li>Europeana employs a licencing framework and a data model to ensure that its collected data is interoperable and re-usable.</li>\r\n</ul>\r\n\r\n<p><strong>A stable platform for developing research tools</strong></p>\r\n\r\n<ul>\r\n    <li>The Europeana API offers a means to access and re-use European\'s data in programmatic form. Via its forthcoming Europeana Cloud service, Europeana is also developing a read/write API for the storing and annotating metadata and content.</li>\r\n</ul>','{\"file\":\"2015-03\\/europeana-research-bg.png\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default',''),
	(27,'team','2015-04-02 10:53:49','2015-04-09 15:54:47','2015-04-02 10:48:28',NULL,'',4,'draft','Team','The team working on Europeana Research','<p>The team working on Europeana Research</p>','<h2>Euroepana Research Management Team</h2>\r\n\r\n<p>Coordinator : <strong>Alastair Dunning</strong> (Europeana Foundation / The European Library)</p>\r\n\r\n<p>Researcher Needs: <strong>Agiatis Benardou</strong> (Digital Curation Unit, Athens)</p>\r\n\r\n<p>Europeana Labs Hookup: <strong>James Morley</strong> (Europeana Foundation)</p>\r\n\r\n<p>Communications Guru: <strong>Nienke van Schaverbeke</strong> (Europeana Foundation / The European Library)</p>\r\n\r\n<h2>Editors and Contributors</h2>\r\n\r\n<p><strong>Marian Lefferts</strong> (Consortium of European Research Libraries)</p>\r\n\r\n<p><strong>Ingeborg Versprille</strong> (Consortium of European Research Libraries)</p>\r\n\r\n<p><strong>Eliza Papaki </strong>(Digital Curation Unit, Athens)</p>\r\n\r\n<p><strong>Kees Waterman</strong> (KNAW / Data Archiving and Networked Services)</p>\r\n\r\n<p><strong>Marnix van Berchum</strong> (KNAW / Data Archiving and Networked Services)</p>\r\n\r\n<p><strong>Stefan Ekman</strong> (University of Gothenburg)</p>\r\n\r\n<p><strong>Ilze Lace</strong> (University of Gothenburg)</p>\r\n\r\n<p><strong>Caspar Jordan</strong> (University of Gothenburg)</p>\r\n\r\n<p><strong>Friedel Grant</strong> (LIBER / Association of European Research Libraries)</p>\r\n\r\n<p><strong>Susan Reilly</strong> (LIBER / Association of European Research Libraries)</p>\r\n\r\n<p><strong>Norman Rodger</strong> (University of Edinburgh)</p>\r\n\r\n<p><strong>Stuart Lewis</strong> (University of Edinburgh)</p>\r\n\r\n<p><strong>Jennifer Edmond</strong>(Trinity College Dublin)</p>\r\n\r\n<p><strong>Vicky Garnett</strong> (Trinity College Dublin)</p>\r\n\r\n<p><strong>Owain Roberts</strong> (National Library of Wales)</p>','{\"file\":\"2015-03\\/europeana-research-bg.png\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default',''),
	(28,'about-europeana-research','2015-04-08 08:45:43','2015-04-09 16:47:14','2015-04-08 08:44:28',NULL,'',4,'published','About Europeana Research','Some slides introducing Europeana Research','<p>Some slides introducing Europeana Research</p>','<p></p>\r\n\r\n<p><iframe allowfullscreen=\"true\" frameborder=\"0\" height=\"749\" mozallowfullscreen=\"true\" src=\"https://docs.google.com/presentation/d/1jFFV7oHpu6Kz9se7oMK9b-yv26K-kk8TezqIkHCy2Lc/embed?start=false&amp;loop=false&amp;delayms=3000\" webkitallowfullscreen=\"true\" width=\"960\"></iframe></p>','{\"file\":\"2015-03\\/europeana-research-bg.png\"}',0,0,'[]','',0,0,'Thumbnail/image grid view','[]','default',''),
	(29,'not-found','2015-04-08 15:26:15','2015-04-09 09:26:38','2015-04-08 15:25:09',NULL,'',2,'published','Sorry we can\'t find this page','Unfortunately we haven\'t found the page you were looking for.','','<p>Why not go back to the Europeana Research home page, or have a look at some content that may interest you.</p>','{\"file\":\"2015-03\\/europeana-research-bg.png\"}',0,1,'[]','',1,0,'Thumbnail/image grid view','[]','default','');

/*!40000 ALTER TABLE `bolt_pages` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_persons
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_persons`;

CREATE TABLE `bolt_persons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `datecreated` datetime NOT NULL,
  `datechanged` datetime NOT NULL,
  `datepublish` datetime DEFAULT NULL,
  `datedepublish` datetime DEFAULT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `ownerid` int(11) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `job_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `department` longtext COLLATE utf8_unicode_ci NOT NULL,
  `team` longtext COLLATE utf8_unicode_ci NOT NULL,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` longtext COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `secondary_email` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone_number` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `other_number` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `linkedin` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `skype` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `other_links_1` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `other_links_2` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `other_links_3` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact_blogpost` tinyint(1) NOT NULL DEFAULT '0',
  `contact_event` tinyint(1) NOT NULL DEFAULT '0',
  `contact_job` tinyint(1) NOT NULL DEFAULT '0',
  `contact_person` tinyint(1) NOT NULL DEFAULT '0',
  `contact_publication` tinyint(1) NOT NULL DEFAULT '0',
  `contact_pressrelease` tinyint(1) NOT NULL DEFAULT '0',
  `contact_taskforce` tinyint(1) NOT NULL DEFAULT '0',
  `contact_tag` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_A932D9E6989D9B62` (`slug`),
  KEY `IDX_A932D9E6AFBA6FD8` (`datecreated`),
  KEY `IDX_A932D9E6BE74E59A` (`datechanged`),
  KEY `IDX_A932D9E6A5131421` (`datepublish`),
  KEY `IDX_A932D9E6B7805520` (`datedepublish`),
  KEY `IDX_A932D9E67B00651C` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_persons` WRITE;
/*!40000 ALTER TABLE `bolt_persons` DISABLE KEYS */;

INSERT INTO `bolt_persons` (`id`, `slug`, `datecreated`, `datechanged`, `datepublish`, `datedepublish`, `username`, `ownerid`, `status`, `first_name`, `last_name`, `company`, `company_url`, `job_title`, `department`, `team`, `introduction`, `image`, `email`, `secondary_email`, `telephone_number`, `other_number`, `linkedin`, `twitter`, `skype`, `other_links_1`, `other_links_2`, `other_links_3`, `contact_blogpost`, `contact_event`, `contact_job`, `contact_person`, `contact_publication`, `contact_pressrelease`, `contact_taskforce`, `contact_tag`)
VALUES
	(1,'alastair-dunning','2015-03-04 15:51:59','2015-04-09 16:33:08','2015-03-04 15:41:48',NULL,'',3,'published','Alastair','Dunning','','','Coordinator','Europeana Staff','Management','<p>Alastair joined The Europeana Library / Europeana Foundation in 2012 as Programme Manager co-ordinating the various projects in which the organisation is involved. He co-ordinates the Europeana Cloud project to create a shared space for Europeana, its aggregators and the cultural heritage sector; Europeana Newspapers, aggregating Europe’s historic newspapers; and CENDARI, whose purpose is to create links between archives and researchers.</p>','{\"file\":\"Images\\/Staff_images_new\\/Alastair.jpg\",\"title\":\"Alastair Dunning\"}','alastair.dunning@europeana.eu','','+31 (0)70 3140 182','','','https://twitter.com/alastairdunning','xcia0069','','','',0,0,0,0,0,0,0,0),
	(2,'agiatis-benardou','2015-04-01 09:09:37','2015-04-09 16:32:50','2015-04-01 09:04:27',NULL,'',7,'published','Agiatis','Benardou','Digital Curation Unit, Athena RC','http://www.dcu.gr/','Researcher Needs','Our Partner','Management','<p>Agiatis holds a PhD in Ancient History and Classical Archaeology and is a Senior Researcher at the Digital Curation Unit, ATHENA R.C. in Athens.</p>\r\n\r\n<p>She is leading the team responsible for assessing researchers\' needs and ensuring community engagement for Europeana Research.</p>\r\n\r\n<p>Agiatis has carried out extensive research on scholarly practices and user requirements in the context of various EU initiatives, such as Preparing DARIAH, EHRI and NeDiMAH. She co-chairs the Special Interest Group on Archaeological Practices and Methods for ARIADNE, the Advanced Research Infrastructure for Archaeological Dataset Networking in Europe, and is a member of the DiRT Steering Committee.</p>\r\n\r\n<p>She is co-chairing the Community Building Working Group of DARIAH-EU and leading the user requirements work for the Erasmus+ Strategic Partnership for the Digital Humanities Reference Curriculum.</p>','{\"file\":\"Europeana_Research\\/agiatis.jpg\",\"title\":\"\"}','a.benardou@dcu.gr','','+30 210 6875428','','','https://twitter.com/agiati','agiatoula','','','',0,0,0,0,0,0,0,0),
	(3,'vicky-garnett','2015-04-02 10:36:49','2015-04-15 12:27:08','2015-04-02 10:33:19',NULL,'',7,'published','Vicky','Garnett','Trinity College Dublin','http://www.tcd.ie/','Researcher','Our Partner','Editors_Contributors','<p>Vicky is the researcher in the Trinity College Dublin team for eCloud. She has previously worked on digital curation projects such as DigCurV and has also worked with DARIAH-IE and collaborated with NeDiMAH.</p>\r\n\r\n<p>Her role within eCloud is mainly investigating user requirements and API use, however she also contributes to strategy via WP5.</p>\r\n\r\n<p>Before moving into Digital Humanities research, Vicky worked in higher education policy development and research funding management.</p>\r\n\r\n<p>Vicky has an MPhil in Linguistics from Trinity College Dublin, and is currently studying part-time for a PhD in Sociolinguistics in the same department.</p>','{\"file\":\"Europeana_Research\\/Vicky.jpg\",\"title\":\"\"}','vicky.garnett@tcd.ie','','+353 01 896 4470','','','','','','','',0,0,0,0,0,0,0,0),
	(4,'stefan-ekman','2015-04-02 10:55:40','2015-04-09 16:00:49','2015-04-02 10:53:30',NULL,'',7,'published','Stefan','Ekman','Swedish National Data Service','http://snd.gu.se/en','Research Coordinator','Our Partner','Editors_Contributors','<p>Stefan holds a PhD in English Literature from Lund University and is currently Research Coordinator for Social Sciences and the Humanities at the Swedish National Data Service (SND). His own research is focused on fantasy literature, and his book Here Be Dragons: Exploring Fantasy Maps and Settings (2013) examines various functions of maps and environments in the genre.<br />\r\n<br />\r\nStefan represents SND in the Europeana Cloud project, and is part of the national coordination of Swe-Clarin, the Swedish consortium of the ESFRI infrastructure CLARIN (Common Language Resources and Technology Infrastructure).</p>','','stefan.ekman@snd.gu.se','','+46 31 786 45 42','','','','','','','',0,0,0,0,0,0,0,0),
	(5,'james-morley','2015-04-09 16:27:45','2015-04-09 16:32:27','2015-04-09 16:25:07',NULL,'',3,'published','James','Morley','','','Europeana Labs Hookup','Europeana Staff','Management','<p>\"Responsible for promoting the Europeana API and supporting innovative re-use of cultural heritage content in the creative industries. James is technically-minded, but also in his spare time a collector, digitiser and sharer of early photography.\"</p>','{\"file\":\"Images\\/Staff_images_new\\/James.jpg\",\"title\":\"James Morley\"}','james.morley@europeana.eu','','+44 (0) 207 412 7114','+44 77 13360563','','https://twitter.com/jamesinealing','jamesinealing','','','',0,0,0,0,0,0,0,0),
	(6,'nienke-van-schaverbeke','2015-04-09 16:31:27','2015-04-09 16:33:23','2015-04-09 16:28:05',NULL,'',3,'published','Nienke','van Schaverbeke','Europeana Foundation','','Communications Guru','Europeana Staff','Management','<p>Nienke joined The European Library (TEL) in 2012. She is responsible for building and maintaining relationships with TEL’s partner libraries, consortia, library systems providers and publishers. She develops TEL’s communication and marketing strategy and co-ordinates all marketing activities. Nienke joins us from Cambridge University Press where she worked as a commissioning editor on the international law list. Prior to working for Cambridge, Nienke gained extensive experience in both marketing and editorial roles at Leuven University Press and Brill Academic Publishers.</p>','{\"file\":\"Images\\/Staff_images_new\\/Nienke2.jpg\",\"title\":\"\"}','nienke.vanschaverbeke@theeuropeanlibrary.org','','+31 (0)70 3140489','','https://www.linkedin.com/in/NienkevanSchaverbeke','https://twitter.com/NvanSchaverbeke','nienkevanschaverbeke','','','',0,0,0,0,0,0,0,0),
	(7,'eliza-papaki','2015-04-15 12:18:32','2015-04-15 12:25:12','2015-04-15 12:17:15',NULL,'',6,'published','Eliza','Papaki','Digital Curation Unit','http://www.dcu.gr/','Research Assistant','Our Partner','Editors_Contributors','','','e.papaki@dcu.gr','','','','','','','','','',0,0,0,0,0,0,0,0);

/*!40000 ALTER TABLE `bolt_persons` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_relations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_relations`;

CREATE TABLE `bolt_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_contenttype` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `from_id` int(11) NOT NULL,
  `to_contenttype` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `to_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4C524BC3EA112943` (`from_contenttype`),
  KEY `IDX_4C524BC378CED90B` (`from_id`),
  KEY `IDX_4C524BC35ACD2645` (`to_contenttype`),
  KEY `IDX_4C524BC330354A65` (`to_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_relations` WRITE;
/*!40000 ALTER TABLE `bolt_relations` DISABLE KEYS */;

INSERT INTO `bolt_relations` (`id`, `from_contenttype`, `from_id`, `to_contenttype`, `to_id`)
VALUES
	(1,'homepage',1,'footers',1),
	(2,'pages',22,'persons',1),
	(4,'structures',2,'persons',1),
	(5,'structures',3,'persons',1),
	(6,'structures',4,'persons',1),
	(7,'footers',1,'locations',1),
	(8,'pages',25,'persons',1),
	(9,'pages',26,'persons',1),
	(10,'pages',21,'persons',2),
	(11,'pages',21,'persons',3),
	(12,'blogposts',181,'persons',4),
	(13,'pages',28,'persons',1),
	(15,'pages',24,'persons',1),
	(16,'structures',5,'persons',1),
	(19,'pages',29,'pages',28),
	(21,'blogposts',182,'persons',1),
	(22,'collections',3,'persons',1),
	(24,'collections',2,'persons',7),
	(25,'collections',1,'persons',4),
	(27,'pages',21,'structures',4),
	(28,'pages',22,'structures',3),
	(29,'pages',24,'structures',3),
	(30,'pages',26,'structures',4),
	(31,'pages',27,'structures',4),
	(32,'collections',1,'structures',2),
	(33,'collections',2,'structures',2),
	(34,'structures',6,'structures',5),
	(35,'persons',1,'structures',6),
	(36,'persons',2,'structures',6),
	(37,'persons',4,'structures',6),
	(38,'persons',3,'structures',6),
	(39,'pages',28,'structures',5),
	(40,'persons',5,'structures',6),
	(41,'persons',6,'structures',6),
	(42,'pages',25,'structures',5),
	(43,'persons',7,'structures',6);

/*!40000 ALTER TABLE `bolt_relations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_structures
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_structures`;

CREATE TABLE `bolt_structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `datecreated` datetime NOT NULL,
  `datechanged` datetime NOT NULL,
  `datepublish` datetime DEFAULT NULL,
  `datedepublish` datetime DEFAULT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `ownerid` int(11) DEFAULT NULL,
  `status` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `secondary_mail` tinyint(1) NOT NULL DEFAULT '0',
  `teaser` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` longtext COLLATE utf8_unicode_ci NOT NULL,
  `template` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `subclass` longtext COLLATE utf8_unicode_ci NOT NULL,
  `footer` longtext COLLATE utf8_unicode_ci NOT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_75591AA989D9B62` (`slug`),
  KEY `IDX_75591AAAFBA6FD8` (`datecreated`),
  KEY `IDX_75591AABE74E59A` (`datechanged`),
  KEY `IDX_75591AAA5131421` (`datepublish`),
  KEY `IDX_75591AAB7805520` (`datedepublish`),
  KEY `IDX_75591AA7B00651C` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_structures` WRITE;
/*!40000 ALTER TABLE `bolt_structures` DISABLE KEYS */;

INSERT INTO `bolt_structures` (`id`, `slug`, `datecreated`, `datechanged`, `datepublish`, `datedepublish`, `username`, `ownerid`, `status`, `title`, `secondary_mail`, `teaser`, `image`, `template`, `content`, `subclass`, `footer`, `date_start`, `date_end`)
VALUES
	(1,'pages','2015-03-04 12:23:05','2015-04-09 09:20:47','2015-03-04 12:21:57',NULL,'',2,'draft','Pages',0,'<p><span style=\"color: rgb(0, 0, 0); font-family: Helvetica, Arial, sans-serif; font-size: 12px; line-height: 18px; background-color: rgb(246, 246, 246);\">Quare ad ea primum, si videtur; Illa videamus, quae a te de amicitia dicta sunt. Facit enim ille duo seiuncta ultima bonorum, quae ut essent vera, coniungi debuerunt; Aliter homines, aliter philosophos loqui putas oportere? Videmus igitur ut conquiescere ne infantes quidem possint.</span></p>','{\"file\":\"2015-03\\/blooming-blossom-branch-2081.jpg\",\"title\":\"\"}','','default','none','0',NULL,NULL),
	(2,'collections','2015-03-04 16:39:06','2015-03-30 10:20:38','2015-03-04 16:37:57',NULL,'',3,'published','Featured collections',0,'<p>A growing list of Europeana collections of interest to the research community.</p>','{\"file\":\"2015-03\\/europeana-research-bg.png\",\"title\":\"\"}','listing_structure.twig','BlogPosts','none','0',NULL,NULL),
	(3,'about-our-data','2015-03-04 16:40:48','2015-03-05 15:56:43','2015-03-04 16:40:08',NULL,'',3,'published','About our data',0,'<p>How the Europeana dataset is aggregated</p>','{\"file\":\"2015-03\\/europeana-research-bg.png\",\"title\":\"\"}','','default','none','0',NULL,NULL),
	(4,'work-with-us','2015-03-04 17:33:58','2015-03-26 16:18:10','2015-03-04 17:33:19',NULL,'',3,'published','Work with us',0,'<p>How the research community can work with Europeana Research</p>','{\"file\":\"2015-03\\/europeana-research-bg.png\",\"title\":\"\"}','','default','none','0',NULL,NULL),
	(5,'about-us','2015-04-09 08:06:50','2015-04-09 14:59:47','2015-04-09 08:06:15',NULL,'',3,'published','About us',0,'','{\"file\":\"2015-03\\/europeana-research-bg.png\",\"title\":\"\"}','overview_structure.twig','default','none','0',NULL,NULL),
	(6,'staff','2015-04-09 15:15:45','2015-04-09 16:10:27','2015-04-09 15:14:41',NULL,'',2,'published','Europeana Research team',0,'<p>Meet our dedicated team at Europeana Research and find out how to get in touch.</p>','','listing_structure.twig','default','none','0',NULL,NULL);

/*!40000 ALTER TABLE `bolt_structures` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_taxonomy
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_taxonomy`;

CREATE TABLE `bolt_taxonomy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_id` int(11) NOT NULL,
  `contenttype` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `taxonomytype` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sortorder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_ABAA120084A0A3ED` (`content_id`),
  KEY `IDX_ABAA1200745E1826` (`contenttype`),
  KEY `IDX_ABAA1200FE2A268F` (`taxonomytype`),
  KEY `IDX_ABAA1200FEA3B3F9` (`sortorder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_taxonomy` WRITE;
/*!40000 ALTER TABLE `bolt_taxonomy` DISABLE KEYS */;

INSERT INTO `bolt_taxonomy` (`id`, `content_id`, `contenttype`, `taxonomytype`, `slug`, `name`, `sortorder`)
VALUES
	(152,21,'pages','tree','work-with-us','Work with us',1),
	(153,22,'pages','tree','about-our-data','About our data',1),
	(155,24,'pages','tree','about-our-data','About our data',0),
	(159,26,'pages','tree','work-with-us','Work with us',2),
	(160,27,'pages','tree','work-with-us','Work with us',3),
	(162,1,'collections','tree','collections','Our collections',0),
	(163,2,'collections','tree','collections','Our collections',0),
	(164,6,'structures','tree','about-us','About us',0),
	(173,1,'persons','tree','staff','Staff',1),
	(174,2,'persons','tree','staff','Staff',6),
	(175,4,'persons','tree','staff','Staff',6),
	(176,3,'persons','tree','staff','Staff',9),
	(177,28,'pages','tree','about-us','About us',0),
	(178,5,'persons','tree','staff','Staff',0),
	(179,6,'persons','tree','staff','Staff',0),
	(180,25,'pages','tree','about-us','About us',1),
	(183,7,'persons','tree','staff','Staff',0);

/*!40000 ALTER TABLE `bolt_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bolt_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bolt_users`;

CREATE TABLE `bolt_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `lastseen` datetime DEFAULT NULL,
  `lastip` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `displayname` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `stack` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `enabled` tinyint(1) NOT NULL,
  `shadowpassword` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `shadowtoken` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `shadowvalidity` datetime DEFAULT NULL,
  `failedlogins` int(11) NOT NULL DEFAULT '0',
  `throttleduntil` datetime DEFAULT NULL,
  `roles` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `IDX_5585B54F85E0677` (`username`),
  KEY `IDX_5585B5450F9BB84` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `bolt_users` WRITE;
/*!40000 ALTER TABLE `bolt_users` DISABLE KEYS */;

INSERT INTO `bolt_users` (`id`, `username`, `password`, `email`, `lastseen`, `lastip`, `displayname`, `stack`, `enabled`, `shadowpassword`, `shadowtoken`, `shadowvalidity`, `failedlogins`, `throttleduntil`, `roles`)
VALUES
	(2,'bob','$P$DwB5VQIHd9X6j9Lpkd5.vx41wVH.eC1','bob@twokings.nl','2015-04-09 15:40:40','62.41.227.121','Bob den Otter','[\"2015-04\\/4xpwp.jpeg\",\"2015-04\\/79ffa223532148abf3bf2f3cbead6795.jpeg\",\"2015-04\\/api.jpg\",\"2015-04\\/4003273528-d78e05f042-b.jpeg\",\"2015-04\\/1q0mw.jpg\",\"2015-03\\/slang.jpg\",\"2015-03\\/blooming-blossom-branch-2081.jpg\",\"2015-03\\/2789604490-066dd1c786-b.jpg\"]',1,'','',NULL,0,NULL,'[\"root\",\"everyone\"]'),
	(3,'dasha','$P$DJrwijaNCysFzyb7c1LvnDhh9wIJAw0','dasha.moskalenko@europeana.eu','2015-04-15 12:06:04','194.171.184.22','Dasha','[\"Images\\/Europeana_Research\\/Wales2.jpg\",\"2015-03\\/alastair.jpg\",\"2015-03\\/150203-solid-black-logo-128px.fw.png\",\"2015-03\\/europeana-research-bg.png\"]',1,'','',NULL,0,NULL,'[\"root\",\"everyone\"]'),
	(10,'labs','$P$DJLWA/k3.K.wIBDDlXRpIBAUkdwhr40','labs@europeana.eu',NULL,'','Labs','[]',1,'','',NULL,0,NULL,'[\"root\"]');

/*!40000 ALTER TABLE `bolt_users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
